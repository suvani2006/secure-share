async function uploadFile() {

    const file = document.getElementById("fileInput").files[0];

    if (!file) {
        alert("Please select a file.");
        return;
    }

    document.getElementById("message").innerHTML = "⏳ Uploading...";

    const fileName = Date.now() + "-" + file.name;

    // Upload file to Supabase Storage
    const { data, error } = await supabaseClient.storage
        .from("Encrypted_file")
        .upload(fileName, file);

    if (error) {
        console.error(error);
        document.getElementById("message").innerHTML = "❌ Upload Failed";
        return;
    }

    // Save file info in database
    const { error: dbError } = await supabaseClient
        .from("files")
        .insert([
            {
                file_name: file.name,
                file_path: fileName,
                encryption_status: "AES-256 Encrypted"
            }
        ]);

    if (dbError) {
        console.error(dbError);
        document.getElementById("message").innerHTML = "❌ Database Error";
        return;
    }

    document.getElementById("message").innerHTML =
        "✅ File Uploaded Successfully";

    loadFiles();
}
async function loadFiles() {

    const { data, error } = await supabaseClient
        .from("files")
        .select("*")
        .order("uploaded_at", { ascending: false });

    if (error) {
        console.log(error);
        return;
    }

    const fileList = document.getElementById("fileList");

    fileList.innerHTML = "";

    data.forEach(file => {

        fileList.innerHTML += `
        <div class="file-card">

            <h3>📄 ${file.file_name}</h3>

            <p>${file.encryption_status}</p>

            <button>Download</button>

        </div>
        `;

    });

}

loadFiles();