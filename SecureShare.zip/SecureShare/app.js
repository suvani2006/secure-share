console.log("🚀 Secure File Vault Pro Loaded");

// ======================================================
// GLOBAL VARIABLES
// ======================================================

let selectedFile = null;
let selectedShareFile = null;

const STORAGE_BUCKET = "files";


// ======================================================
// PAGE LOAD
// ======================================================

document.addEventListener("DOMContentLoaded", async function () {

    console.log("📄 Dashboard Loaded");

    checkSupabase();

    setupFileInput();

    // RSA sharing key setup
    try {

        await ensureUserSharingKeys();

    }
    catch (error) {

        console.error(
            "❌ RSA sharing key setup failed:",
            error
        );

    }

    // Existing functions - DON'T CHANGE
    await loadFiles();
    await loadSharedFiles();
    loadActivityLog();

});


// ======================================================
// FILE INPUT SETUP
// ======================================================

function setupFileInput() {

    const fileInput =
        document.getElementById("fileInput");

    if (!fileInput) {

        console.warn(
            "⚠️ fileInput element not found."
        );

        return;
    }

    fileInput.addEventListener(
        "change",
        function () {

            if (
                fileInput.files &&
                fileInput.files.length > 0
            ) {

                selectedFile =
                    fileInput.files[0];

                console.log(
                    "📄 File selected:",
                    selectedFile.name
                );

            }
            else {

                selectedFile = null;

            }

        }
    );

    console.log(
        "✅ File input setup completed."
    );
}


// ======================================================
// CHECK SUPABASE
// ======================================================

function checkSupabase() {

    if (
        typeof supabaseClient ===
        "undefined"
    ) {

        console.error(
            "❌ Supabase client not found"
        );

        alert(
            "❌ Supabase connection failed."
        );

        return false;
    }

    console.log(
        "✅ Supabase client available"
    );

    return true;
}


// ======================================================
// ENSURE USER RSA SHARING KEYS
// ======================================================
// ======================================================
// GET OR GENERATE LOCAL RSA SHARING KEY PAIR
// ======================================================

async function ensureLocalSharingKeyPair() {

    const STORAGE_KEY = "secure_file_vault_rsa_keypair";

    try {

        // Check if an existing RSA key pair is already stored
        const existingKeys =
            localStorage.getItem(STORAGE_KEY);

        if (existingKeys) {

            const stored =
                JSON.parse(existingKeys);

            const publicKey =
                await crypto.subtle.importKey(
                    "jwk",
                    stored.publicKey,
                    {
                        name: "RSA-OAEP",
                        hash: "SHA-256"
                    },
                    true,
                    ["encrypt"]
                );

            const privateKey =
                await crypto.subtle.importKey(
                    "jwk",
                    stored.privateKey,
                    {
                        name: "RSA-OAEP",
                        hash: "SHA-256"
                    },
                    true,
                    ["decrypt"]
                );

            console.log(
                "🔑 Existing RSA sharing key pair loaded."
            );

            return {
                publicKey: JSON.stringify(stored.publicKey),
                privateKey: privateKey,
                publicKeyObject: publicKey
            };
        }


        // Generate a new RSA key pair
        console.log(
            "🔐 Generating new RSA sharing key pair..."
        );

        const keyPair =
            await crypto.subtle.generateKey(
                {
                    name: "RSA-OAEP",
                    modulusLength: 2048,
                    publicExponent:
                        new Uint8Array([1, 0, 1]),
                    hash: "SHA-256"
                },
                true,
                ["encrypt", "decrypt"]
            );


        // Export keys so they can be stored locally
        const publicKeyJWK =
            await crypto.subtle.exportKey(
                "jwk",
                keyPair.publicKey
            );

        const privateKeyJWK =
            await crypto.subtle.exportKey(
                "jwk",
                keyPair.privateKey
            );


        // Store the RSA key pair locally
        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify({
                publicKey: publicKeyJWK,
                privateKey: privateKeyJWK
            })
        );


        console.log(
            "✅ New RSA sharing key pair generated and stored."
        );


        return {
            publicKey:
                JSON.stringify(publicKeyJWK),

            privateKey:
                keyPair.privateKey,

            publicKeyObject:
                keyPair.publicKey
        };

    }
    catch (error) {

        console.error(
            "❌ RSA key pair setup failed:",
            error
        );

        throw error;
    }
}
async function ensureUserSharingKeys() {

    console.log(
        "🔐 Setting up user sharing keys..."
    );

    const {
        data: userData,
        error: userError
    } =
        await supabaseClient
            .auth
            .getUser();


    if (userError) {

        throw userError;
    }


    if (
        !userData ||
        !userData.user
    ) {

        throw new Error(
            "User is not logged in."
        );
    }


    const userId =
        userData.user.id;

    const userEmail =
        userData.user.email;


    // ====================================
    // GET OR GENERATE LOCAL RSA KEY PAIR
    // ====================================

    const keyPair =
        await ensureLocalSharingKeyPair();

    const publicKey =
        keyPair.publicKey;


    // ====================================
    // SAVE PUBLIC KEY + EMAIL
    // ====================================

    const {
        error: keyError
    } =
        await supabaseClient
            .from("user_keys")
            .upsert(
                {
                    user_id:
                        userId,

                    email:
                        userEmail,

                    public_key:
                        publicKey
                },
                {
                    onConflict:
                        "user_id"
                }
            );


    if (keyError) {

        console.error(
            "❌ Failed to save user sharing key:",
            keyError
        );

        throw keyError;
    }


    console.log(
        "✅ User RSA public key synced with Supabase."
    );

    console.log(
        "👤 User ID:",
        userId
    );

    console.log(
        "📧 User Email:",
        userEmail
    );

    return true;
}


// ======================================================
// SHA-256 GENERATOR
// ======================================================

async function generateSHA256(file) {

    if (!file) {

        throw new Error(
            "File is missing."
        );
    }


    const buffer =
        await file.arrayBuffer();


    const hashBuffer =
        await crypto.subtle.digest(
            "SHA-256",
            buffer
        );


    const hashArray =
        Array.from(
            new Uint8Array(
                hashBuffer
            )
        );


    return hashArray
        .map(
            byte =>
                byte
                    .toString(16)
                    .padStart(
                        2,
                        "0"
                    )
        )
        .join("");
}


// ======================================================
// GET FILE KEY ID
// ======================================================

async function getFileKeyId(filePath) {

    if (!filePath) {

        throw new Error(
            "File path is missing."
        );
    }


    console.log(
        "🔑 Getting encryption key ID for:",
        filePath
    );


    const {
        data,
        error
    } =
        await supabaseClient
            .from("files")
            .select("key_id")
            .eq(
                "file_path",
                filePath
            )
            .single();


    if (error) {

        console.error(
            "❌ Could not get key_id:",
            error
        );

        throw new Error(
            "Could not get encryption key information: " +
            error.message
        );
    }


    if (
        !data ||
        !data.key_id
    ) {

        throw new Error(
            "Encryption key ID is not available for this file."
        );
    }


    console.log(
        "🔑 Key ID:",
        data.key_id
    );


    return data.key_id;
}


// ======================================================
// UPLOAD FILE
// ======================================================

async function uploadFile() {
    const {
    data: { user },
    error: userError
} = await supabaseClient.auth.getUser();

if (userError || !user) {
    throw new Error("User authentication required.");
}

    console.log(
        "🔒 Upload button clicked"
    );

    console.log(
        "🧪 REAL uploadFile() STARTED"
    );


    const fileInput =
        document.getElementById(
            "fileInput"
        );


    const message =
        document.getElementById(
            "message"
        );


    if (
        !fileInput ||
        !fileInput.files ||
        !fileInput.files.length
    ) {

        setMessage(
            message,
            "❌ Please select a file first."
        );

        return;
    }


    const file =
        fileInput.files[0];


    try {

        // ==================================================
        // STEP 1: GENERATE SHA-256
        // ==================================================

        setMessage(
            message,
            "🔍 Generating file integrity hash..."
        );


        const fileHash =
            await generateSHA256(
                file
            );


        console.log(
            "🔐 SHA-256 File Hash:",
            fileHash
        );


        // ==================================================
        // STEP 2: ENCRYPT FILE
        // ==================================================

        setMessage(
            message,
            "🔐 Encrypting file..."
        );


        if (
            typeof encryptFile !==
            "function"
        ) {

            throw new Error(
                "encryptFile() not found. Check encryption.js."
            );
        }


        const encryptionResult =
            await encryptFile(
                file
            );


        if (
            !encryptionResult ||
            !encryptionResult.encryptedData
        ) {

            throw new Error(
                "Encryption failed. encryptedData was not returned."
            );
        }


        const encryptedData =
            encryptionResult.encryptedData;


        const keyId =
            encryptionResult.keyId;


        if (!keyId) {

            throw new Error(
                "Encryption key ID was not generated."
            );
        }


        console.log(
            "🔐 Encryption Key ID:",
            keyId
        );


        // ==================================================
        // STEP 3: CREATE FILE PATH
        // ==================================================

        const filePath =
            Date.now() +
            "_" +
            sanitizeFileName(
                file.name
            );


        console.log(
            "📁 File path:",
            filePath
        );


        // ==================================================
        // STEP 4: UPLOAD ENCRYPTED FILE
        // ==================================================

        // ==================================================
// STEP 4: UPLOAD ENCRYPTED FILE
// ==================================================

setMessage(
    message,
    "☁️ Uploading encrypted file..."
);

const encryptedBlob = new Blob(
    [encryptedData],
    {
        type: "application/octet-stream"
    }
);

const {
    data: uploadData,
    error: uploadError
} = await supabaseClient
    .storage
    .from(STORAGE_BUCKET)
    .upload(
        filePath,
        encryptedBlob,
        {
            contentType: "application/octet-stream",
            upsert: false,
            cacheControl: "3600"
        }
    );

if (uploadError) {

    console.error(
        "❌ Storage Upload Error:",
        uploadError
    );

    setMessage(
        message,
        "❌ Upload failed: " +
        uploadError.message
    );

    return;
}

console.log(
    "✅ Storage Upload Success:",
    uploadData
);

console.log(
    "✅ Encrypted file uploaded"
);


        // ==================================================
        // STEP 5: GET CURRENT USER
        // ==================================================

        setMessage(
            message,
            "📝 Saving file information..."
        );


        const {
            data: userData,
            error: userError
        } =
            await supabaseClient
                .auth
                .getUser();


        if (
            userError ||
            !userData ||
            !userData.user
        ) {

            console.error(
                "❌ User Error:",
                userError
            );


            await supabaseClient
                .storage
                .from(STORAGE_BUCKET)
                .remove([
                    filePath
                ]);


            setMessage(
                message,
                "❌ Please login first."
            );


            return;
        }


        console.log(
            "👤 Current user:",
            userData.user.email
        );


        // ==================================================
        // STEP 6: SAVE DATABASE RECORD
        // ==================================================

        const {
            error: dbError
        } =
            await supabaseClient
                .from("files")
                .insert([
                    {

                        file_name:
                            file.name,

                        file_path:
                            filePath,

                        encryption_status:
                            "AES-256-GCM Encrypted",

                        file_hash:
                            fileHash,

                        key_id:
                            keyId,

                        file_size:
                            file.size,
                            user_id: user.id,

                        created_at:
                            new Date().toISOString()

                    }
                ]);


        if (dbError) {

            console.error(
                "❌ Database Error:",
                dbError
            );


            await supabaseClient
                .storage
                .from(STORAGE_BUCKET)
                .remove([
                    filePath
                ]);


            setMessage(
                message,
                "❌ Database error: " +
                dbError.message
            );


            return;
        }


        console.log(
            "✅ Database record created"
        );


        console.log(
            "🔐 Saved SHA-256:",
            fileHash
        );


        console.log(
            "🔑 Saved Key ID:",
            keyId
        );


        // ==================================================
        // STEP 7: SUCCESS
        // ==================================================

        setMessage(
            message,
            "✅ File uploaded and encrypted successfully!"
        );


        fileInput.value = "";

        selectedFile = null;


        await loadFiles();


        addActivity(
            "📤 Uploaded",
            file.name
        );

    }

    catch (error) {

        console.error(
            "❌ Upload Error:",
            error
        );


        setMessage(
            message,
            "❌ Upload failed: " +
            error.message
        );
    }
}


// ======================================================
// LOAD FILES
// ======================================================

async function loadFiles() {

    console.log(
        "🔥 loadFiles started"
    );


    const fileList =
        document.getElementById(
            "fileList"
        );


    const fileCount =
        document.getElementById(
            "fileCount"
        );


    if (!fileList) {

        console.error(
            "❌ fileList element not found"
        );

        return;
    }


    fileList.innerHTML =
        "<p>🔄 Loading files...</p>";


    try {

        const {
            data,
            error
        } =
            await supabaseClient
                .from("files")
                .select("*")
                .is(
                    "deleted_at",
                    null
                )
                .order(
                    "created_at",
                    {
                        ascending:
                            false
                    }
                );


        console.log(
            "📦 Files Result:",
            {
                data,
                error
            }
        );


        if (error) {

            console.error(
                "❌ Database Error:",
                error
            );


            fileList.innerHTML =
                "<p>❌ " +
                escapeHtml(
                    error.message
                ) +
                "</p>";


            return;
        }


        const validFiles =
            (data || []).filter(
                file =>
                    file &&
                    file.file_name &&
                    file.file_path
            );


        if (fileCount) {

            fileCount.textContent =
                validFiles.length;
        }


        if (!validFiles.length) {

            fileList.innerHTML =
                "<p>📂 No valid files found.</p>";

            return;
        }


        fileList.innerHTML =
            "";


        // ==================================================
        // CREATE FILE CARDS
        // ==================================================

        validFiles.forEach(
            file => {

                console.log(
                    "📄 FILE DATA:",
                    {
                        id:
                            file.id,

                        file_name:
                            file.file_name,

                        file_path:
                            file.file_path,

                        key_id:
                            file.key_id
                    }
                );


                const card =
                    document.createElement(
                        "div"
                    );


                card.className =
                    "file-card";


                card.innerHTML = `

                    <h3>
                        📄 ${escapeHtml(
                            file.file_name
                        )}
                    </h3>

                    <p>
                        🔐 Encryption:
                        ${escapeHtml(
                            file.encryption_status ||
                            "AES-256-GCM Encrypted"
                        )}
                    </p>

                    <p>
                        📦 Size:
                        ${formatFileSize(
                            file.file_size
                        )}
                    </p>

                    <p>
                        📅 ${escapeHtml(
                            formatDate(
                                file.created_at
                            )
                        )}
                    </p>

                    <p>
                        📁 ${escapeHtml(
                            file.file_path
                        )}
                    </p>

                    <div class="file-buttons">

                        <button
                            type="button"
                            class="preview-btn"
                        >
                            👁️ Preview
                        </button>

                        <button
                            type="button"
                            class="download-btn"
                        >
                            ⬇️ Download
                        </button>

                        <button
                            type="button"
                            class="share-btn"
                        >
                            🔗 Share
                        </button>

                        <button
                            type="button"
                            class="verify-btn"
                        >
                            🛡️ Verify Integrity
                        </button>

                    </div>
                `;


                const previewBtn =
                    card.querySelector(
                        ".preview-btn"
                    );


                const downloadBtn =
                    card.querySelector(
                        ".download-btn"
                    );


                const shareBtn =
                    card.querySelector(
                        ".share-btn"
                    );


                const verifyBtn =
                    card.querySelector(
                        ".verify-btn"
                    );


                // ==================================================
                // PREVIEW
                // ==================================================

                if (previewBtn) {

                    previewBtn.addEventListener(
                        "click",
                        () => {

                            previewFile(
                                file.file_path,
                                file.file_name,
                                file.key_id
                            );

                        }
                    );
                }


                // ==================================================
                // DOWNLOAD
                // ==================================================

                if (downloadBtn) {

                    downloadBtn.addEventListener(
                        "click",
                        () => {

                            downloadFile(
                                file.file_path,
                                file.file_name,
                                file.key_id
                            );

                        }
                    );
                }


                // ==================================================
                // SHARE
                // ==================================================

                if (shareBtn) {

                    shareBtn.addEventListener(
                        "click",
                        () => {

                            openShareModal(
                                file.file_path,
                                file.file_name,
                                file.key_id
                            );

                        }
                    );
                }


                // ==================================================
                // VERIFY INTEGRITY
                // ==================================================

                if (verifyBtn) {

                    verifyBtn.addEventListener(
                        "click",
                        () => {

                            verifyFileIntegrity(
                                file.file_path,
                                file.file_name,
                                file.key_id
                            );

                        }
                    );
                }


                fileList.appendChild(
                    card
                );

            }
        );


        console.log(
            "✅ Files displayed successfully"
        );

    }

    catch (error) {

        console.error(
            "❌ loadFiles error:",
            error
        );


        fileList.innerHTML =
            "<p>❌ Something went wrong: " +
            escapeHtml(
                error.message
            ) +
            "</p>";
    }
}


// ======================================================
// PREVIEW FILE
// ======================================================

async function previewFile(
    filePath,
    fileName,
    keyId
) {

    console.log(
        "👁️ Preview:",
        {
            filePath,
            fileName,
            keyId
        }
    );


    if (
        !filePath ||
        !fileName
    ) {

        alert(
            "❌ File information is missing."
        );

        return;
    }


    const previewWindow =
        window.open(
            "",
            "_blank"
        );


    if (!previewWindow) {

        alert(
            "❌ Please allow pop-ups for this site."
        );

        return;
    }


    previewWindow.document.write(`

        <html>

        <head>
            <title>Loading...</title>
        </head>

        <body style="
            font-family:Arial;
            text-align:center;
            padding:50px;
        ">

            <h2>
                🔐 Decrypting file...
            </h2>

            <p>
                Please wait.
            </p>

        </body>

        </html>

    `);


    try {

        // ==================================================
        // GET KEY ID
        // ==================================================

        if (!keyId) {

            console.log(
                "🔑 keyId not supplied. Getting from database..."
            );


            keyId =
                await getFileKeyId(
                    filePath
                );
        }


        // ==================================================
        // DOWNLOAD ENCRYPTED FILE
        // ==================================================

        const {
            data,
            error
        } =
            await supabaseClient
                .storage
                .from(STORAGE_BUCKET)
                .download(
                    filePath
                );


        if (error) {

            throw new Error(
                error.message
            );
        }


        if (!data) {

            throw new Error(
                "No file data received."
            );
        }


        const encryptedData =
            await data.arrayBuffer();


        // ==================================================
        // DECRYPT
        // ==================================================

        if (
            typeof decryptFile !==
            "function"
        ) {

            throw new Error(
                "decryptFile() not found. Check encryption.js."
            );
        }


        const decryptedData =
            await decryptFile(
                encryptedData,
                keyId
            );


        // ==================================================
        // CREATE BLOB
        // ==================================================

        const blob =
            new Blob(
                [
                    decryptedData
                ],
                {
                    type:
                        getMimeType(
                            fileName
                        )
                }
            );


        const url =
            URL.createObjectURL(
                blob
            );


        const extension =
            getExtension(
                fileName
            );


        let content = "";


        // ==================================================
        // IMAGE
        // ==================================================

        if (
            [
                "jpg",
                "jpeg",
                "jfif",
                "png",
                "gif",
                "webp"
            ].includes(
                extension
            )
        ) {

            content = `

                <div style="
                    background:#111;
                    min-height:100vh;
                    display:flex;
                    justify-content:center;
                    align-items:center;
                    padding:20px;
                ">

                    <img
                        src="${url}"
                        alt="${escapeHtml(
                            fileName
                        )}"
                        style="
                            max-width:100%;
                            max-height:95vh;
                            object-fit:contain;
                        "
                    >

                </div>

            `;
        }


        // ==================================================
        // PDF
        // ==================================================

        else if (
            extension === "pdf"
        ) {

            content = `

                <iframe
                    src="${url}"
                    style="
                        width:100%;
                        height:100vh;
                        border:0;
                    "
                ></iframe>

            `;
        }


        // ==================================================
        // VIDEO
        // ==================================================

        else if (
            [
                "mp4",
                "webm",
                "ogg"
            ].includes(
                extension
            )
        ) {

            content = `

                <div style="
                    background:#111;
                    min-height:100vh;
                    display:flex;
                    justify-content:center;
                    align-items:center;
                ">

                    <video
                        controls
                        autoplay
                        style="
                            max-width:95%;
                            max-height:95vh;
                        "
                    >

                        <source
                            src="${url}"
                            type="${getMimeType(
                                fileName
                            )}"
                        >

                    </video>

                </div>

            `;
        }


        // ==================================================
        // AUDIO
        // ==================================================

        else if (
            [
                "mp3",
                "wav",
                "ogg"
            ].includes(
                extension
            )
        ) {

            content = `

                <div style="
                    font-family:Arial;
                    text-align:center;
                    padding:60px;
                ">

                    <h2>
                        🎵 ${escapeHtml(
                            fileName
                        )}
                    </h2>

                    <audio
                        controls
                        autoplay
                        src="${url}"
                    ></audio>

                </div>

            `;
        }


        // ==================================================
        // TEXT
        // ==================================================

        else if (
            [
                "txt",
                "csv",
                "json",
                "log"
            ].includes(
                extension
            )
        ) {

            const text =
                await new Response(
                    blob
                ).text();


            content = `

                <div style="
                    padding:30px;
                    font-family:Arial;
                ">

                    <h2>
                        📄 ${escapeHtml(
                            fileName
                        )}
                    </h2>

                    <pre style="
                        white-space:pre-wrap;
                        word-break:break-word;
                        text-align:left;
                    ">${escapeHtml(
                        text
                    )}</pre>

                </div>

            `;
        }


        // ==================================================
        // OTHER FILE
        // ==================================================

        else {

            content = `

                <div style="
                    font-family:Arial;
                    text-align:center;
                    padding:60px;
                ">

                    <h2>
                        📄 ${escapeHtml(
                            fileName
                        )}
                    </h2>

                    <p>
                        Preview is not available
                        for this file type.
                    </p>

                    <p>
                        Please use Download.
                    </p>

                </div>

            `;
        }


        // ==================================================
        // WRITE PREVIEW
        // ==================================================

        previewWindow.document.open();


        previewWindow.document.write(`

            <!DOCTYPE html>

            <html>

            <head>

                <meta charset="UTF-8">

                <title>
                    ${escapeHtml(
                        fileName
                    )}
                </title>

            </head>

            <body
                style="
                    margin:0;
                "
            >

                ${content}

            </body>

            </html>

        `);


        previewWindow.document.close();


        console.log(
            "✅ Preview opened:",
            fileName
        );


        addActivity(
            "👁️ Previewed",
            fileName
        );


        previewWindow.addEventListener(
            "beforeunload",
            () => {

                URL.revokeObjectURL(
                    url
                );

            }
        );

    }

    catch (error) {

        console.error(
            "❌ Preview Exception:",
            error
        );


        try {

            previewWindow.close();

        }

        catch (_) {}


        alert(
            "❌ Preview failed: " +
            error.message
        );
    }
}


// ======================================================
// DOWNLOAD FILE
// ======================================================

async function downloadFile(
    filePath,
    fileName,
    keyId
) {

    console.log(
        "⬇️ Download:",
        {
            filePath,
            fileName,
            keyId
        }
    );


    try {

        if (
            !filePath ||
            !fileName
        ) {

            throw new Error(
                "File information is missing."
            );
        }


        // ==================================================
        // GET KEY ID
        // ==================================================

        if (!keyId) {

            keyId =
                await getFileKeyId(
                    filePath
                );
        }


        // ==================================================
        // GET ENCRYPTED FILE
        // ==================================================

        const {
            data,
            error
        } =
            await supabaseClient
                .storage
                .from(STORAGE_BUCKET)
                .download(
                    filePath
                );


        if (error) {

            throw new Error(
                error.message
            );
        }


        if (!data) {

            throw new Error(
                "No encrypted file data received."
            );
        }


        const encryptedData =
            await data.arrayBuffer();


        // ==================================================
        // DECRYPT
        // ==================================================

        if (
            typeof decryptFile !==
            "function"
        ) {

            throw new Error(
                "decryptFile() not found. Check encryption.js."
            );
        }


        const decryptedData =
            await decryptFile(
                encryptedData,
                keyId
            );


        // ==================================================
        // ORIGINAL FILE BLOB
        // ==================================================

        const blob =
            new Blob(
                [
                    decryptedData
                ],
                {
                    type:
                        getMimeType(
                            fileName
                        )
                }
            );


        const url =
            URL.createObjectURL(
                blob
            );


        // ==================================================
        // DOWNLOAD
        // ==================================================

        const link =
            document.createElement(
                "a"
            );


        link.href =
            url;


        link.download =
            fileName;


        document.body.appendChild(
            link
        );


        link.click();


        link.remove();


        setTimeout(
            () => {

                URL.revokeObjectURL(
                    url
                );

            },
            1000
        );


        addActivity(
            "⬇️ Downloaded",
            fileName
        );


        console.log(
            "✅ Original file downloaded:",
            fileName
        );

    }

    catch (error) {

        console.error(
            "❌ Download Exception:",
            error
        );


        alert(
            "❌ Download failed: " +
            error.message
        );
    }
}


// ======================================================
// SEARCH FILES
// ======================================================

function searchFiles() {

    const input =
        document.getElementById(
            "searchFiles"
        );


    const cards =
        document.querySelectorAll(
            ".file-card"
        );


    if (!input) {

        return;
    }


    const search =
        input.value
            .toLowerCase()
            .trim();


    cards.forEach(
        card => {

            const text =
                card.textContent
                    .toLowerCase();


            card.style.display =
                text.includes(
                    search
                )
                    ? ""
                    : "none";

        }
    );
}


// ======================================================
// SHARE MODAL
// ======================================================

function openShareModal(
    filePath,
    fileName,
    keyId
) {

    console.log(
        "🔗 Share Debug:",
        {
            filePath,
            fileName,
            keyId
        }
    );


    if (
        !filePath ||
        !fileName
    ) {

        alert(
            "❌ Cannot share: file information missing."
        );

        return;
    }


    selectedShareFile = {

        path:
            filePath,

        name:
            fileName,

        keyId:
            keyId || null

    };


    const modal =
        document.getElementById(
            "shareModal"
        );


    const name =
        document.getElementById(
            "shareFileName"
        );


    const email =
        document.getElementById(
            "shareEmail"
        );


    const permission =
        document.getElementById(
            "sharePermission"
        );


    const message =
        document.getElementById(
            "shareMessage"
        );


    if (!modal) {

        alert(
            "❌ Share modal not found."
        );

        return;
    }


    if (name) {

        name.textContent =
            fileName;
    }


    if (email) {

        email.value =
            "";
    }


    if (permission) {

        permission.value =
            "view";
    }


    if (message) {

        message.textContent =
            "";
    }


    modal.style.display =
        "flex";


    document.body.style.overflow =
        "hidden";


    console.log(
        "✅ Share modal opened"
    );
}


// ======================================================
// CLOSE SHARE MODAL
// ======================================================

function closeShareModal() {

    const modal =
        document.getElementById(
            "shareModal"
        );


    if (modal) {

        modal.style.display =
            "none";
    }


    document.body.style.overflow =
        "";


    selectedShareFile =
        null;
}


// ======================================================
// SHARE FILE
// ======================================================
// ======================================================
// SHARE FILE
// ======================================================

async function shareFile() {

    console.log(
        "🔗 Secure file sharing started..."
    );

    try {

        // ====================================
        // GET SHARE DETAILS
        // ====================================

        const emailInput =
            document.getElementById("shareEmail");

        const permissionInput =
            document.getElementById("sharePermission");

        if (!emailInput) {
            throw new Error(
                "Share email field not found."
            );
        }

        if (!permissionInput) {
            throw new Error(
                "Share permission field not found."
            );
        }

        const email =
            emailInput.value
                .trim()
                .toLowerCase();

        const permission =
            permissionInput.value;

        if (!email) {

            alert(
                "❌ Please enter recipient email."
            );

            return;
        }

        // Basic email validation
        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email)) {

            alert(
                "❌ Please enter a valid email address."
            );

            return;
        }

        if (!selectedShareFile) {

            throw new Error(
                "No file selected for sharing."
            );
        }

        // ====================================
        // GET CURRENT USER
        // ====================================

        const {
            data: userData,
            error: userError
        } =
            await supabaseClient
                .auth
                .getUser();

        if (
            userError ||
            !userData ||
            !userData.user
        ) {

            throw new Error(
                "User is not logged in."
            );
        }

        const ownerId =
            userData.user.id;

        const ownerEmail =
            userData.user.email || "";

        console.log(
            "👤 Share owner:",
            ownerEmail
        );

        console.log(
            "📧 Recipient:",
            email
        );

        console.log(
            "🔐 Permission:",
            permission
        );

        // ====================================
        // GET FILE KEY ID
        // ====================================

       console.log(
    "🔎 Selected share file:",
    selectedShareFile
);

if (!selectedShareFile) {
    throw new Error(
        "No file selected for sharing. Please click Share again."
    );
}

let keyId =
    selectedShareFile.keyId;

if (!keyId) {

    console.log(
        "ℹ️ File key ID missing. Trying to retrieve it from file path..."
    );

    keyId =
        await getFileKeyId(
            selectedShareFile.path
        );
}

if (!keyId) {
    throw new Error(
        "Encryption key ID is not available for this file."
    );
}

console.log(
    "🔑 File Key ID:",
    keyId
);

        if (!keyId) {

            keyId =
                await getFileKeyId(
                    selectedShareFile.path
                );
        }

        if (!keyId) {

            throw new Error(
                "Encryption key ID is not available."
            );
        }

        console.log(
            "🔑 File Key ID:",
            keyId
        );

        // ====================================
        // SEARCH RECIPIENT PUBLIC KEY
        // ====================================

        console.log(
            "🔍 Searching recipient public key..."
        );

        const {
            data: recipientKeyData,
            error: recipientKeyError
        } =
            await supabaseClient
                .from("user_keys")
                .select(
                    "user_id, public_key, email"
                )
                .eq(
                    "email",
                    email
                )
                .maybeSingle();

        if (recipientKeyError) {

            console.error(
                "❌ Recipient key lookup error:",
                recipientKeyError
            );

            throw new Error(
                recipientKeyError.message
            );
        }

        let wrappedKey = null;

        // ====================================
        // REGISTERED RECIPIENT
        // ====================================

        if (
            recipientKeyData &&
            recipientKeyData.public_key
        ) {

            console.log(
                "✅ Recipient public key found."
            );

            console.log(
                "👤 Recipient:",
                recipientKeyData.email
            );

            // ====================================
            // WRAP AES KEY
            // ====================================

            if (
                typeof wrapAESKeyForSharing !==
                "function"
            ) {

                throw new Error(
                    "wrapAESKeyForSharing() not found. Check encryption.js."
                );
            }

            console.log(
                "🔐 Wrapping AES file key for recipient..."
            );

            wrappedKey =
                await wrapAESKeyForSharing(
                    keyId,
                    recipientKeyData.public_key
                );

            if (!wrappedKey) {

                throw new Error(
                    "Failed to wrap AES encryption key."
                );
            }

            console.log(
                "✅ AES key securely wrapped."
            );
        }

        // ====================================
        // NEW / UNREGISTERED RECIPIENT
        // ====================================

        else {

            console.log(
                "ℹ️ Recipient has no SecureShare account yet."
            );

            console.log(
                "📨 Creating pending secure share..."
            );

            wrappedKey = null;
        }

        // ====================================
        // SAVE SHARE RECORD
        // ====================================

        const {
            data: shareData,
            error: shareError
        } =
            await supabaseClient
                .from("file_shares")
                .insert([
                    {
                        file_path:
                            selectedShareFile.path,

                        shared_with_email:
                            email,

                        permission:
                            permission,

                        owner_id:
                            ownerId,

                        key_id:
                            keyId,

                        wrapped_key:
                            wrappedKey
                    }
                ])
                .select();

        if (shareError) {

            console.error(
                "❌ Share Database Error:",
                shareError
            );

            throw new Error(
                shareError.message
            );
        }

        console.log(
            "✅ Share record created:",
            shareData
        );

        // ====================================
        // SEND EMAIL NOTIFICATION
        // ====================================

        console.log(
            "📧 Sending share email..."
        );

        const shareLink =
    "https://secureshare-2.vercel.app/shared.html?share=" +
    shareData[0].id;

        const {
            data: emailResult,
            error: emailError
        } =
            await supabaseClient
                .functions
                .invoke(
                    "send-share-email",
                    {
                        body: {

                            recipientEmail:
                                email,

                            senderName:
                                userData.user
                                    .user_metadata
                                    ?.full_name ||
                                ownerEmail ||
                                "Secure File Vault User",

                            fileName:
                                selectedShareFile.name,

                            shareLink:
                                shareLink
                        }
                    }
                );

        if (emailError) {

            console.error(
                "❌ Email sending failed:",
                emailError
            );

            alert(
                "⚠️ Share was created, but the email could not be sent.\n\n" +
                "Reason: " +
                emailError.message
            );

        } else if (
            !emailResult ||
            !emailResult.success
        ) {

            console.error(
                "❌ Email service error:",
                emailResult
            );

            alert(
                "⚠️ Share was created, but the email could not be sent."
            );

        } else {

            console.log(
                "✅ Share email sent successfully:",
                emailResult
            );
        }

        // ====================================
        // SUCCESS MESSAGE
        // ====================================

        const message =
            document.getElementById(
                "shareMessage"
            );

        if (message) {

            if (wrappedKey) {

                message.textContent =
                    "✅ File shared securely!";

            } else {

                message.textContent =
                    "📨 Invitation sent. Recipient needs to sign up.";
            }
        }

        // ====================================
        // FINAL ALERT
        // ====================================

        if (wrappedKey) {

            alert(
                "✅ File shared successfully!\n\n" +
                "Recipient: " +
                email +
                "\nPermission: " +
                permission
            );

        } else {

            alert(
                "📨 Invitation sent successfully!\n\n" +
                "Recipient: " +
                email +
                "\n\n" +
                "The recipient can sign up and then access the shared file."
            );
        }

        // ====================================
        // ACTIVITY LOG
        // ====================================

        addActivity(
            "🔗 Shared",
            selectedShareFile.name
        );

        console.log(
            "🎉 Secure sharing process completed."
        );

        closeShareModal();

        await loadSharedFiles();

    }

    catch (error) {

        console.error(
            "❌ Secure sharing error:",
            error
        );

        alert(
            "❌ Sharing failed: " +
            error.message
        );
    }
}
// ======================================================
// SHARE ENTIRE VAULT
// ======================================================

async function shareAllFiles() {

    console.log("🔗 Share Entire Vault started...");

    try {

        // ====================================
        // GET SHARE DETAILS
        // ====================================

        const emailInput =
            document.getElementById("shareEmail");

        const permissionInput =
            document.getElementById("sharePermission");

        if (!emailInput || !permissionInput) {

            throw new Error(
                "Share form fields not found."
            );
        }

        const email =
            emailInput.value
                .trim()
                .toLowerCase();

        const permission =
            permissionInput.value;

        if (!email) {

            alert(
                "❌ Please enter recipient email."
            );

            return;
        }

        // ====================================
        // VALIDATE EMAIL
        // ====================================

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email)) {

            alert(
                "❌ Please enter a valid email address."
            );

            return;
        }

        // ====================================
        // GET CURRENT USER
        // ====================================

        const {
            data: userData,
            error: userError
        } =
            await supabaseClient
                .auth
                .getUser();

        if (
            userError ||
            !userData ||
            !userData.user
        ) {

            throw new Error(
                "User is not logged in."
            );
        }

        const ownerId =
            userData.user.id;

        const ownerEmail =
            userData.user.email || "";

        console.log(
            "👤 Vault owner:",
            ownerEmail
        );

        console.log(
            "📧 Vault recipient:",
            email
        );

        console.log(
            "🔐 Vault permission:",
            permission
        );

        // ====================================
        // GET ALL OWNER FILES
        // ====================================

        console.log(
            "📂 Getting all vault files..."
        );

        const {
            data: files,
            error: filesError
        } =
            await supabaseClient
                .from("files")
                .select(
                    "id, file_name, file_path, key_id, deleted_at"
                )
                .eq(
                    "user_id",
                    ownerId
                )
                .is(
                    "deleted_at",
                    null
                )
                .order(
                    "created_at",
                    {
                        ascending: false
                    }
                );

        if (filesError) {

            throw new Error(
                "Could not load vault files: " +
                filesError.message
            );
        }

        if (
            !files ||
            !files.length
        ) {

            alert(
                "📂 Your vault does not contain any files."
            );

            return;
        }

        console.log(
            "📦 Total vault files:",
            files.length
        );

        // ====================================
        // GET RECIPIENT PUBLIC KEY
        // ====================================

        console.log(
            "🔍 Searching recipient public key..."
        );

        const {
            data: recipientKeyData,
            error: recipientKeyError
        } =
            await supabaseClient
                .from("user_keys")
                .select(
                    "user_id, public_key, email"
                )
                .eq(
                    "email",
                    email
                )
                .maybeSingle();

        if (recipientKeyError) {

            throw new Error(
                "Recipient key lookup failed: " +
                recipientKeyError.message
            );
        }

        if (
            !recipientKeyData ||
            !recipientKeyData.public_key
        ) {

            alert(
                "📨 This user has not registered a Secure File Vault account yet.\n\n" +
                "Please ask them to create an account first."
            );

            return;
        }

        console.log(
            "✅ Recipient public key found."
        );

        // ====================================
        // SHARE EACH FILE
        // ====================================

        let successCount = 0;
        let failedCount = 0;

        const failedFiles = [];

        for (
            const file of files
        ) {

            try {

                console.log(
                    "🔐 Sharing:",
                    file.file_name
                );

                // -----------------------------
                // CHECK KEY ID
                // -----------------------------

                if (!file.key_id) {

                    throw new Error(
                        "Encryption key ID missing."
                    );
                }

                // -----------------------------
                // WRAP AES KEY
                // -----------------------------

                const wrappedKey =
                    await wrapAESKeyForSharing(
                        file.key_id,
                        recipientKeyData.public_key
                    );

                if (!wrappedKey) {

                    throw new Error(
                        "AES key wrapping failed."
                    );
                }

                console.log(
                    "✅ AES key wrapped:",
                    file.file_name
                );

                // -----------------------------
                // CHECK EXISTING SHARE
                // -----------------------------

                const {
                    data: existingShare,
                    error: existingShareError
                } =
                    await supabaseClient
                        .from("file_shares")
                        .select("id")
                        .eq(
                            "file_path",
                            file.file_path
                        )
                        .eq(
                            "shared_with_email",
                            email
                        )
                        .maybeSingle();

                if (existingShareError) {

                    throw new Error(
                        existingShareError.message
                    );
                }

                // -----------------------------
                // UPDATE EXISTING SHARE
                // -----------------------------

                if (existingShare) {

                    const {
                        error: updateError
                    } =
                        await supabaseClient
                            .from("file_shares")
                            .update({
                                permission:
                                    permission,

                                key_id:
                                    file.key_id,

                                wrapped_key:
                                    wrappedKey
                            })
                            .eq(
                                "id",
                                existingShare.id
                            );

                    if (updateError) {

                        throw new Error(
                            updateError.message
                        );
                    }

                    console.log(
                        "♻️ Existing share updated:",
                        file.file_name
                    );

                }

                // -----------------------------
                // CREATE NEW SHARE
                // -----------------------------

                else {

                    const {
                        error: insertError
                    } =
                        await supabaseClient
                            .from("file_shares")
                            .insert([
                                {
                                    file_path:
                                        file.file_path,

                                    shared_with_email:
                                        email,

                                    permission:
                                        permission,

                                    owner_id:
                                        ownerId,

                                    key_id:
                                        file.key_id,

                                    wrapped_key:
                                        wrappedKey
                                }
                            ]);

                    if (insertError) {

                        throw new Error(
                            insertError.message
                        );
                    }

                    console.log(
                        "✅ New share created:",
                        file.file_name
                    );
                }

                successCount++;

            }

            catch (fileError) {

                failedCount++;

                failedFiles.push(
                    file.file_name
                );

                console.error(
                    "❌ Failed to share:",
                    file.file_name,
                    fileError
                );
            }
        }

        // ====================================
        // RESULT
        // ====================================

        console.log(
            "🎉 Vault sharing completed."
        );

        console.log(
            "✅ Successful:",
            successCount
        );

        console.log(
            "❌ Failed:",
            failedCount
        );

        // ====================================
        // ACTIVITY LOG
        // ====================================

        addActivity(
            "🔗 Shared Entire Vault",
            `${successCount} files with ${email}`
        );

        // ====================================
        // SUCCESS MESSAGE
        // ====================================

        let resultMessage =
            "✅ Vault sharing completed!\n\n" +
            "Recipient: " +
            email +
            "\n\n" +
            "Files shared: " +
            successCount;

        if (failedCount > 0) {

            resultMessage +=
                "\nFiles failed: " +
                failedCount +
                "\n\nFailed files:\n" +
                failedFiles.join("\n");
        }

        alert(
            resultMessage
        );

        // ====================================
        // CLOSE MODAL
        // ====================================

        closeShareModal();

        await loadSharedFiles();

    }

    catch (error) {

        console.error(
            "❌ Share Entire Vault error:",
            error
        );

        alert(
            "❌ Vault sharing failed:\n\n" +
            error.message
        );
    }
}
// ======================================================
// LOAD SHARED FILES
// ======================================================

async function loadSharedFiles() {

    console.log(
        "🔗 Loading shared files..."
    );


    const container =
        document.getElementById(
            "sharedFilesList"
        );


    if (!container) {

        console.log(
            "ℹ️ sharedFilesList not found"
        );

        return;
    }


    container.innerHTML =
        "<p>🔄 Loading shared files...</p>";


    try {

        const {
            data: userData,
            error: userError
        } =
            await supabaseClient
                .auth
                .getUser();


        if (
            userError ||
            !userData ||
            !userData.user
        ) {

            container.innerHTML =
                "<p>❌ Please login first.</p>";

            return;
        }


        const userEmail =
            (
                userData.user.email ||
                ""
            )
                .trim()
                .toLowerCase();


        console.log(
            "👤 Current user:",
            userEmail
        );


        const {
            data,
            error
        } =
            await supabaseClient
                .from("file_shares")
                .select("*")
                .eq(
                    "shared_with_email",
                    userEmail
                )
                .order(
                    "created_at",
                    {
                        ascending:
                            false
                    }
                );


        console.log(
            "📦 My Shared Files:",
            {
                data,
                error
            }
        );


        if (error) {

            throw new Error(
                error.message
            );
        }


        if (
            !data ||
            !data.length
        ) {

            container.innerHTML =
                "<p>📂 No files have been shared with you.</p>";

            return;
        }


        container.innerHTML =
            "";


        data.forEach(
            share => {

                if (
                    !share ||
                    !share.file_path
                ) {

                    console.warn(
                        "⚠️ Skipping incomplete shared record:",
                        share?.id
                    );

                    return;
                }


                const card =
                    document.createElement(
                        "div"
                    );


                card.className =
                    "shared-file-card";


                const fileName =
                    getFileNameFromPath(
                        share.file_path
                    );


                const permission =
                    share.permission ===
                    "download"
                        ? "download"
                        : "view";


                card.innerHTML = `

                    <h3>
                        🔗 ${escapeHtml(
                            fileName
                        )}
                    </h3>

                    <p>
                        📁 ${escapeHtml(
                            share.file_path
                        )}
                    </p>

                    <p>
                        🔐 Permission:
                        ${escapeHtml(
                            permission
                        )}
                    </p>

                    <p>
                        📧 Shared with:
                        ${escapeHtml(
                            share.shared_with_email ||
                            ""
                        )}
                    </p>

                    <p>
                        📅 ${escapeHtml(
                            formatDate(
                                share.created_at
                            )
                        )}
                    </p>

                    <div
                        class="shared-file-buttons"
                    >

                        <button
                            type="button"

                            class="shared-view-btn"
                        >
                            👁️ View
                        </button>

                        <button
                            type="button"
                            class="shared-download-btn"
                        >
                            ⬇️ Download
                        </button>

                    </div>
                `;


                const viewBtn =
                    card.querySelector(
                        ".shared-view-btn"
                    );


                const downloadBtn =
                    card.querySelector(
                        ".shared-download-btn"
                    );


                if (viewBtn) {

                    viewBtn.addEventListener(
                        "click",
                        () => {

                            viewSharedFile(
                                share.file_path,
                                fileName,
                                permission
                            );

                        }
                    );
                }


                if (downloadBtn) {

                    downloadBtn.addEventListener(
                        "click",
                        () => {

                            downloadSharedFile(
                                share.file_path,
                                fileName,
                                permission
                            );

                        }
                    );
                }


                container.appendChild(
                    card
                );

            }
        );


        console.log(
            "✅ My shared files displayed successfully"
        );

    }

    catch (error) {

        console.error(
            "❌ loadSharedFiles Exception:",
            error
        );


        container.innerHTML =
            "<p>❌ Something went wrong: " +
            escapeHtml(
                error.message
            ) +
            "</p>";
    }
}

// ======================================================
// VIEW SHARED FILE - MOBILE FRIENDLY
// ======================================================

async function viewSharedFile(
    filePath,
    fileName,
    permission
) {

    console.log(
        "👁️ View Shared File:",
        {
            filePath,
            fileName,
            permission
        }
    );

    if (
        permission !== "view" &&
        permission !== "download"
    ) {

        alert(
            "❌ You do not have permission to view this file."
        );

        return;
    }

    // --------------------------------------------------
    // GET CURRENT USER
    // --------------------------------------------------

    try {

        const {
            data: userData,
            error: userError
        } =
            await supabaseClient.auth.getUser();

        if (
            userError ||
            !userData ||
            !userData.user
        ) {

            throw new Error(
                "User is not logged in."
            );
        }

        const userEmail =
            (
                userData.user.email || ""
            )
                .trim()
                .toLowerCase();


        // --------------------------------------------------
        // GET SHARE RECORD
        // --------------------------------------------------

        const {
            data: shareData,
            error: shareError
        } =
            await supabaseClient
                .from("file_shares")
                .select(
                    "wrapped_key, key_id, permission"
                )
                .eq(
                    "file_path",
                    filePath
                )
                .eq(
                    "shared_with_email",
                    userEmail
                )
                .order(
                    "created_at",
                    {
                        ascending: false
                    }
                )
                .limit(1)
                .maybeSingle();


        if (shareError) {

            throw new Error(
                shareError.message
            );
        }


        if (
            !shareData ||
            !shareData.wrapped_key
        ) {

            throw new Error(
                "Secure wrapped encryption key not found."
            );
        }


        // --------------------------------------------------
        // GET RSA PRIVATE KEY
        // --------------------------------------------------

        if (
            typeof getSharingPrivateKey !==
            "function"
        ) {

            throw new Error(
                "getSharingPrivateKey() not found. Check encryption.js."
            );
        }


        const privateKey =
            await getSharingPrivateKey();


        if (!privateKey) {

            throw new Error(
                "Secure sharing private key not found."
            );
        }


        // --------------------------------------------------
        // UNWRAP AES KEY
        // --------------------------------------------------

        if (
            typeof unwrapAESKeyFromSharing !==
            "function"
        ) {

            throw new Error(
                "unwrapAESKeyFromSharing() not found. Check encryption.js."
            );
        }


        const aesKey =
            await unwrapAESKeyFromSharing(
                shareData.wrapped_key,
                privateKey
            );


        if (!aesKey) {

            throw new Error(
                "Unable to recover AES encryption key."
            );
        }


        console.log(
            "✅ AES key recovered successfully."
        );


        // --------------------------------------------------
        // DOWNLOAD ENCRYPTED FILE
        // --------------------------------------------------

        const {
            data,
            error
        } =
            await supabaseClient
                .storage
                .from(STORAGE_BUCKET)
                .download(
                    filePath
                );


        if (error) {

            throw new Error(
                error.message
            );
        }


        if (!data) {

            throw new Error(
                "No shared file data received."
            );
        }


        const encryptedData =
            await data.arrayBuffer();


        // --------------------------------------------------
        // DECRYPT
        // --------------------------------------------------

        if (
            typeof decryptWithKey !==
            "function"
        ) {

            throw new Error(
                "decryptWithKey() not found. Check encryption.js."
            );
        }


        const decryptedData =
            await decryptWithKey(
                encryptedData,
                aesKey
            );


        // --------------------------------------------------
        // CREATE ORIGINAL FILE BLOB
        // --------------------------------------------------

        const mimeType =
            getMimeType(
                fileName
            );

        const blob =
            new Blob(
                [
                    decryptedData
                ],
                {
                    type: mimeType
                }
            );


        const url =
            URL.createObjectURL(
                blob
            );


        // --------------------------------------------------
        // MOBILE-FRIENDLY PREVIEW
        // --------------------------------------------------

        const extension =
            getExtension(
                fileName
            );


        let content = "";


        // IMAGE
        if (
            [
                "jpg",
                "jpeg",
                "jfif",
                "png",
                "gif",
                "webp"
            ].includes(
                extension
            )
        ) {

            content = `

                <div style="
                    min-height:100vh;
                    background:#111;
                    display:flex;
                    flex-direction:column;
                    justify-content:center;
                    align-items:center;
                    padding:15px;
                    box-sizing:border-box;
                ">

                    <h3 style="
                        color:white;
                        font-family:Arial;
                        text-align:center;
                        word-break:break-word;
                    ">
                        ${escapeHtml(fileName)}
                    </h3>

                    <img
                        src="${url}"
                        alt="${escapeHtml(fileName)}"
                        style="
                            max-width:100%;
                            max-height:80vh;
                            object-fit:contain;
                        "
                    >

                    <a
                        href="${url}"
                        download="${escapeHtml(fileName)}"
                        style="
                            margin-top:20px;
                            padding:12px 20px;
                            background:#00c8ff;
                            color:#000;
                            text-decoration:none;
                            border-radius:8px;
                            font-family:Arial;
                            font-weight:bold;
                        "
                    >
                        ⬇️ Download
                    </a>

                </div>
            `;
        }


        // PDF
        else if (
            extension === "pdf"
        ) {

            content = `

                <div style="
                    width:100%;
                    height:100vh;
                    margin:0;
                    padding:0;
                ">

                    <iframe
                        src="${url}"
                        style="
                            width:100%;
                            height:100%;
                            border:0;
                        "
                    ></iframe>

                </div>
            `;
        }


        // VIDEO
        else if (
            [
                "mp4",
                "webm",
                "ogg"
            ].includes(
                extension
            )
        ) {

            content = `

                <div style="
                    min-height:100vh;
                    background:#111;
                    display:flex;
                    flex-direction:column;
                    justify-content:center;
                    align-items:center;
                    padding:15px;
                    box-sizing:border-box;
                ">

                    <video
                        controls
                        playsinline
                        style="
                            width:100%;
                            max-height:80vh;
                        "
                    >

                        <source
                            src="${url}"
                            type="${mimeType}"
                        >

                    </video>

                    <a
                        href="${url}"
                        download="${escapeHtml(fileName)}"
                        style="
                            margin-top:20px;
                            padding:12px 20px;
                            background:#00c8ff;
                            color:#000;
                            text-decoration:none;
                            border-radius:8px;
                            font-family:Arial;
                            font-weight:bold;
                        "
                    >
                        ⬇️ Download
                    </a>

                </div>
            `;
        }


        // AUDIO
        else if (
            [
                "mp3",
                "wav",
                "ogg",
                "m4a"
            ].includes(
                extension
            )
        ) {

            content = `

                <div style="
                    min-height:100vh;
                    display:flex;
                    flex-direction:column;
                    justify-content:center;
                    align-items:center;
                    padding:20px;
                    box-sizing:border-box;
                    font-family:Arial;
                ">

                    <h2 style="
                        text-align:center;
                        word-break:break-word;
                    ">
                        🎵 ${escapeHtml(fileName)}
                    </h2>

                    <audio
                        controls
                        style="
                            width:100%;
                            max-width:500px;
                        "
                    >

                        <source
                            src="${url}"
                            type="${mimeType}"
                        >

                    </audio>

                    <a
                        href="${url}"
                        download="${escapeHtml(fileName)}"
                        style="
                            margin-top:20px;
                            padding:12px 20px;
                            background:#00c8ff;
                            color:#000;
                            text-decoration:none;
                            border-radius:8px;
                            font-weight:bold;
                        "
                    >
                        ⬇️ Download
                    </a>

                </div>
            `;
        }


        // TEXT
        else if (
            [
                "txt",
                "csv",
                "json",
                "log"
            ].includes(
                extension
            )
        ) {

            const text =
                await new Response(
                    blob
                ).text();


            content = `

                <div style="
                    padding:20px;
                    font-family:Arial;
                    box-sizing:border-box;
                ">

                    <h2 style="
                        word-break:break-word;
                    ">
                        📄 ${escapeHtml(fileName)}
                    </h2>

                    <pre style="
                        white-space:pre-wrap;
                        word-break:break-word;
                        overflow-wrap:anywhere;
                    ">${escapeHtml(text)}</pre>

                </div>
            `;
        }


        // OTHER FILE TYPES
        else {

            content = `

                <div style="
                    min-height:100vh;
                    display:flex;
                    flex-direction:column;
                    justify-content:center;
                    align-items:center;
                    padding:25px;
                    text-align:center;
                    font-family:Arial;
                    box-sizing:border-box;
                ">

                    <h2>
                        📄 ${escapeHtml(fileName)}
                    </h2>

                    <p>
                        Preview is not available
                        for this file type.
                    </p>

                    <a
                        href="${url}"
                        download="${escapeHtml(fileName)}"
                        style="
                            margin-top:20px;
                            padding:12px 20px;
                            background:#00c8ff;
                            color:#000;
                            text-decoration:none;
                            border-radius:8px;
                            font-weight:bold;
                        "
                    >
                        ⬇️ Download File
                    </a>

                </div>
            `;
        }


        // --------------------------------------------------
        // OPEN MOBILE-FRIENDLY PREVIEW
        // --------------------------------------------------

        const previewWindow =
            window.open(
                "",
                "_blank"
            );


        if (!previewWindow) {

            // If popup is blocked, open the decrypted
            // file directly in the current tab.

            window.location.href = url;

            return;
        }


        previewWindow.document.open();


        previewWindow.document.write(`

            <!DOCTYPE html>

            <html>

            <head>

                <meta
                    charset="UTF-8"
                >

                <meta
                    name="viewport"
                    content="width=device-width, initial-scale=1.0"
                >

                <title>
                    ${escapeHtml(fileName)}
                </title>

            </head>

            <body style="
                margin:0;
                padding:0;
            ">

                ${content}

            </body>

            </html>

        `);


        previewWindow.document.close();


        addActivity(
            "👁️ Viewed Shared",
            fileName
        );


        setTimeout(
            () => {

                URL.revokeObjectURL(
                    url
                );

            },
            30 * 60 * 1000
        );


        console.log(
            "✅ Shared file opened successfully on mobile/desktop."
        );

    }

    catch (error) {

        console.error(
            "❌ View Shared File Exception:",
            error
        );


        alert(
            "❌ Unable to view shared file: " +
            error.message
        );
    }
}


// ======================================================
// DOWNLOAD SHARED FILE
// ======================================================

async function downloadSharedFile(
    filePath,
    fileName,
    permission
) {

    console.log(
        "⬇️ Download Shared File:",
        {
            filePath,
            fileName,
            permission
        }
    );


    if (
        permission !==
        "download"
    ) {

        alert(
            "❌ You only have View permission for this file."
        );

        return;
    }


    try {

        // ==================================================
        // GET SHARE RECORD
        // ==================================================

       const {
    data: userData,
    error: userError
} = await supabaseClient.auth.getUser();

if (userError || !userData || !userData.user) {
    throw new Error("User is not logged in.");
}

const userEmail = (
    userData.user.email || ""
).trim().toLowerCase();

const {
    data: shareData,
    error: shareError
} =
    await supabaseClient
        .from("file_shares")
        .select(
            "wrapped_key, key_id, permission"
        )
        .eq(
            "file_path",
            filePath
        )
        .eq(
            "shared_with_email",
            userEmail
        )
        .order(
            "created_at",
            {
                ascending: false
            }
        )
        .limit(1)
        .maybeSingle();

        if (shareError) {

            throw new Error(
                shareError.message
            );
        }


        if (
            !shareData ||
            !shareData.wrapped_key
        ) {

            throw new Error(
                "Secure wrapped encryption key not found."
            );
        }


        // ==================================================
        // GET RSA PRIVATE KEY
        // ==================================================

        if (
            typeof getSharingPrivateKey !==
            "function"
        ) {

            throw new Error(
                "getSharingPrivateKey() not found. Check encryption.js."
            );
        }


        const privateKey =
            await getSharingPrivateKey();


        if (!privateKey) {

            throw new Error(
                "Secure sharing private key not found."
            );
        }


        // ==================================================
        // UNWRAP AES KEY
        // ==================================================

        if (
            typeof unwrapAESKeyFromSharing !==
            "function"
        ) {

            throw new Error(
                "unwrapAESKeyFromSharing() not found. Check encryption.js."
            );
        }


        const aesKey =
            await unwrapAESKeyFromSharing(
                shareData.wrapped_key,
                privateKey
            );


        if (!aesKey) {

            throw new Error(
                "Unable to recover AES encryption key."
            );
        }


        console.log(
            "✅ AES key recovered for download."
        );


        // ==================================================
        // DOWNLOAD ENCRYPTED FILE
        // ==================================================

        const {
            data,
            error
        } =
            await supabaseClient
                .storage
                .from(STORAGE_BUCKET)
                .download(
                    filePath
                );


        if (error) {

            throw new Error(
                error.message
            );
        }


        if (!data) {

            throw new Error(
                "No shared file data received."
            );
        }


        const encryptedData =
            await data.arrayBuffer();


        // ==================================================
        // DIRECT DECRYPTION
        // ==================================================

        if (
            typeof decryptWithKey !==
            "function"
        ) {

            throw new Error(
                "decryptWithKey() not found. Check encryption.js."
            );
        }


        const decryptedData =
            await decryptWithKey(
                encryptedData,
                aesKey
            );


        // ==================================================
        // CREATE BLOB
        // ==================================================

        const blob =
            new Blob(
                [
                    decryptedData
                ],
                {
                    type:
                        getMimeType(
                            fileName
                        )
                }
            );


        const url =
            URL.createObjectURL(
                blob
            );


        // ==================================================
        // DOWNLOAD
        // ==================================================

        const link =
            document.createElement(
                "a"
            );


        link.href =
            url;


        link.download =
            fileName;


        document.body.appendChild(
            link
        );


        link.click();


        link.remove();


        setTimeout(
            () => {

                URL.revokeObjectURL(
                    url
                );

            },
            1000
        );


        addActivity(
            "⬇️ Downloaded Shared",
            fileName
        );


        console.log(
            "✅ Shared file downloaded successfully."
        );

    }

    catch (error) {

        console.error(
            "❌ Shared Download Exception:",
            error
        );


        alert(
            "❌ Unable to download shared file: " +
            error.message
        );
    }
}


// ======================================================
// VERIFY FILE INTEGRITY
// ======================================================

async function verifyFileIntegrity(
    filePath,
    fileName,
    keyId
) {

    console.log(
        "🔍 Verifying file integrity:",
        {
            filePath,
            fileName,
            keyId
        }
    );


    try {

        if (
            !filePath ||
            !fileName
        ) {

            throw new Error(
                "File information is missing."
            );
        }


        // ==================================================
        // GET FILE RECORD
        // ==================================================

        const {
            data: fileRecord,
            error: dbError
        } =
            await supabaseClient
                .from("files")
                .select(
                    "file_hash, key_id"
                )
                .eq(
                    "file_path",
                    filePath
                )
                .single();


        if (dbError) {

            throw new Error(
                "Could not find file record: " +
                dbError.message
            );
        }


        if (
            !fileRecord ||
            !fileRecord.file_hash
        ) {

            throw new Error(
                "SHA-256 hash not found for this file."
            );
        }


        const storedHash =
            fileRecord.file_hash;


        console.log(
            "🔐 Stored SHA-256:",
            storedHash
        );


        // ==================================================
        // GET KEY ID
        // ==================================================

        keyId =
            keyId ||
            fileRecord.key_id;


        if (!keyId) {

            throw new Error(
                "Encryption key ID is not available for this file."
            );
        }


        console.log(
            "🔑 Integrity verification Key ID:",
            keyId
        );


        // ==================================================
        // DOWNLOAD ENCRYPTED FILE
        // ==================================================

        const {
            data,
            error: downloadError
        } =
            await supabaseClient
                .storage
                .from(STORAGE_BUCKET)
                .download(
                    filePath
                );


        if (downloadError) {

            throw new Error(
                "Could not download file: " +
                downloadError.message
            );
        }


        if (!data) {

            throw new Error(
                "No file data received."
            );
        }


        const encryptedData =
            await data.arrayBuffer();


        // ==================================================
        // DECRYPT
        // ==================================================

        if (
            typeof decryptFile !==
            "function"
        ) {

            throw new Error(
                "decryptFile() not found. Check encryption.js."
            );
        }


        const decryptedData =
            await decryptFile(
                encryptedData,
                keyId
            );


        // ==================================================
        // CALCULATE SHA-256
        // ==================================================

        const calculatedHash =
            await generateSHA256(
                new Blob(
                    [
                        decryptedData
                    ]
                )
            );


        console.log(
            "🔍 Calculated SHA-256:",
            calculatedHash
        );


        // ==================================================
        // COMPARE HASHES
        // ==================================================

        if (
            calculatedHash.toLowerCase() ===
            storedHash.toLowerCase()
        ) {

            console.log(
                "✅ FILE INTEGRITY VERIFIED"
            );


            alert(
                "✅ File Integrity Verified!\n\n" +
                fileName +
                "\n\n" +
                "SHA-256 hash matches."
            );


            addActivity(
                "🛡️ Integrity Verified",
                fileName
            );


            return true;
        }


        // ==================================================
        // HASH MISMATCH
        // ==================================================

        console.error(
            "❌ FILE INTEGRITY FAILED"
        );


        console.error(
            "Stored Hash:",
            storedHash
        );


        console.error(
            "Calculated Hash:",
            calculatedHash
        );


        alert(
            "⚠️ File Integrity Failed!\n\n" +
            fileName +
            "\n\n" +
            "SHA-256 hash does NOT match."
        );


        addActivity(
            "⚠️ Integrity Failed",
            fileName
        );


        return false;

    }

    catch (error) {

        console.error(
            "❌ Integrity Verification Error:",
            error
        );


        alert(
            "❌ Integrity verification failed:\n\n" +
            error.message
        );


        return false;
    }
}


// ======================================================
// GET FILE NAME FROM PATH
// ======================================================

function getFileNameFromPath(
    filePath
) {

    if (!filePath) {

        return "Shared File";
    }


    const lastPart =
        String(filePath)
            .split("/")
            .pop();


    if (!lastPart) {

        return "Shared File";
    }


    const underscoreIndex =
        lastPart.indexOf("_");


    if (
        underscoreIndex !==
        -1
    ) {

        return lastPart.substring(
            underscoreIndex + 1
        );
    }


    return lastPart;
}


// ======================================================
// MIME TYPE
// ======================================================

function getMimeType(
    fileName
) {

    const extension =
        getExtension(
            fileName
        );


    const mimeTypes = {

        jpg:
            "image/jpeg",

        jpeg:
            "image/jpeg",

        jfif:
            "image/jpeg",

        png:
            "image/png",

        gif:
            "image/gif",

        webp:
            "image/webp",

        pdf:
            "application/pdf",

        txt:
            "text/plain",

        csv:
            "text/csv",

        json:
            "application/json",

        log:
            "text/plain",

        mp4:
            "video/mp4",

        webm:
            "video/webm",

        ogg:
            "video/ogg",

        mp3:
            "audio/mpeg",

        wav:
            "audio/wav"

    };


    return (
        mimeTypes[
            extension
        ] ||
        "application/octet-stream"
    );
}


// ======================================================
// FILE EXTENSION
// ======================================================

function getExtension(
    fileName
) {

    return String(
        fileName || ""
    )
        .split(".")
        .pop()
        .toLowerCase();
}


// ======================================================
// SANITIZE FILE NAME
// ======================================================

function sanitizeFileName(
    fileName
) {

    return String(
        fileName || "file"
    )
        .replace(
            /[<>:"/\\|?*\x00-\x1F]/g,
            "_"
        )
        .trim();
}


// ======================================================
// FORMAT FILE SIZE
// ======================================================

function formatFileSize(
    bytes
) {

    if (
        bytes === null ||
        bytes === undefined ||
        bytes === ""
    ) {

        return "Unknown";
    }


    const size =
        Number(bytes);


    if (
        Number.isNaN(size)
    ) {

        return "Unknown";
    }


    if (
        size < 1024
    ) {

        return size + " B";
    }


    if (
        size < 1024 * 1024
    ) {

        return (
            (size / 1024)
                .toFixed(2) +
            " KB"
        );
    }


    if (
        size < 1024 * 1024 * 1024
    ) {

        return (
            (size / (1024 * 1024))
                .toFixed(2) +
            " MB"
        );
    }


    return (
        (size / (1024 * 1024 * 1024))
            .toFixed(2) +
        " GB"
    );
}


// ======================================================
// ACTIVITY LOG
// ======================================================

function addActivity(
    action,
    fileName
) {

    const log =
        document.getElementById(
            "activityLog"
        );


    if (!log) {

        return;
    }


    const firstChild =
        log.firstElementChild;


    if (
        firstChild &&
        firstChild.textContent ===
            "No recent activity."
    ) {

        firstChild.remove();
    }


    const item =
        document.createElement(
            "p"
        );


    item.textContent =
        `${action} - ${fileName} - ${new Date().toLocaleString()}`;


    log.prepend(
        item
    );
}


// ======================================================
// LOAD ACTIVITY LOG
// ======================================================

function loadActivityLog() {

    const log =
        document.getElementById(
            "activityLog"
        );


    if (!log) {

        return;
    }


    if (
        !log.children.length
    ) {

        log.innerHTML =
            "<p>No recent activity.</p>";
    }
}


// ======================================================
// FORMAT DATE
// ======================================================

function formatDate(
    date
) {

    if (!date) {

        return "Unknown date";
    }


    const parsed =
        new Date(
            date
        );


    if (
        Number.isNaN(
            parsed.getTime()
        )
    ) {

        return "Unknown date";
    }


    return parsed.toLocaleString();
}


// ======================================================
// SET MESSAGE
// ======================================================

function setMessage(
    element,
    text
) {

    if (element) {

        element.textContent =
            text;
    }
}


// ======================================================
// ESCAPE HTML
// ======================================================

function escapeHtml(
    text
) {

    const div =
        document.createElement(
            "div"
        );


    div.textContent =
        text ?? "";


    return div.innerHTML;
}


// ======================================================
// GLOBAL FUNCTIONS
// ======================================================

window.uploadFile =
    uploadFile;

window.loadFiles =
    loadFiles;

window.previewFile =
    previewFile;

window.downloadFile =
    downloadFile;

window.searchFiles =
    searchFiles;

window.openShareModal =
    openShareModal;

window.closeShareModal =
    closeShareModal;

window.shareFile =
    shareFile;

window.loadSharedFiles =
    loadSharedFiles;

window.viewSharedFile =
    viewSharedFile;

window.downloadSharedFile =
    downloadSharedFile;

window.getFileNameFromPath =
    getFileNameFromPath;

window.getMimeType =
    getMimeType;

window.verifyFileIntegrity =
    verifyFileIntegrity;

window.getFileKeyId =
    getFileKeyId;

window.generateSHA256 =
    generateSHA256;


// ======================================================
// FINAL LOGS
// ======================================================

console.log(
    "✅ app.js loaded successfully"
);

console.log(
    "🔗 Share functions connected"
);

console.log(
    "🛡️ SHA-256 integrity verification connected"
);

console.log(
    "🔑 Encryption key ID handling connected"
);

console.log(
    "🔐 RSA secure sharing connected"
);