console.log("🔗 share.js Loaded");

// ========================================
// SELECTED FILE
// ========================================

window.selectedShareFile = null;


// ========================================
// OPEN SHARE MODAL
// ========================================

function openShareModal(filePath, fileName) {

    console.log(
        "🔗 Opening Share Modal:",
        fileName
    );

    const modal =
        document.getElementById("shareModal");

    if (!modal) {

        console.error(
            "❌ shareModal not found"
        );

        alert(
            "❌ Share modal not found."
        );

        return;
    }


    // ========================================
    // STORE SELECTED FILE
    // ========================================

    window.selectedShareFile = {

        path: filePath,

        name: fileName

    };


    // ========================================
    // FILE NAME
    // ========================================

    const fileNameElement =
        document.getElementById("shareFileName");

    if (fileNameElement) {

        fileNameElement.textContent =
            fileName;

    }


    // ========================================
    // EMAIL
    // ========================================

    const emailInput =
        document.getElementById("shareEmail");

    if (emailInput) {

        emailInput.value = "";

    }


    // ========================================
    // PERMISSION
    // ========================================

    const permissionInput =
        document.getElementById("sharePermission");

    if (permissionInput) {

        permissionInput.value =
            "view";

    }


    // ========================================
    // MESSAGE
    // ========================================

    const message =
        document.getElementById("shareMessage");

    if (message) {

        message.textContent = "";

    }


    // ========================================
    // SHOW MODAL
    // ========================================

    modal.style.display = "flex";

    document.body.style.overflow =
        "hidden";


    console.log(
        "✅ Share modal opened"
    );
}


// ========================================
// CLOSE SHARE MODAL
// ========================================

function closeShareModal() {

    const modal =
        document.getElementById("shareModal");

    if (modal) {

        modal.style.display =
            "none";

    }

    document.body.style.overflow =
        "";

    window.selectedShareFile =
        null;


    console.log(
        "✅ Share modal closed"
    );
}


// ========================================
// SHARE FILE
// ========================================

async function shareFile() {

    console.log(
        "🔗 Share File clicked"
    );


    // ========================================
    // CHECK SELECTED FILE
    // ========================================

    if (!window.selectedShareFile) {

        alert(
            "❌ Please select a file first."
        );

        return;
    }


    // ========================================
    // GET ELEMENTS
    // ========================================

    const emailInput =
        document.getElementById("shareEmail");

    const permissionInput =
        document.getElementById("sharePermission");

    const message =
        document.getElementById("shareMessage");


    if (!emailInput) {

        console.error(
            "❌ shareEmail element not found"
        );

        return;
    }


    // ========================================
    // GET VALUES
    // ========================================

    const email =
        emailInput.value
            .trim()
            .toLowerCase();


    const permission =
        permissionInput
            ? permissionInput.value
            : "view";


    // ========================================
    // VALIDATE EMAIL
    // ========================================

    if (!email) {

        if (message) {

            message.textContent =
                "❌ Please enter a user email.";

            message.style.color =
                "#ff5c5c";

        }

        return;
    }


    const emailPattern =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


    if (!emailPattern.test(email)) {

        if (message) {

            message.textContent =
                "❌ Please enter a valid email.";

            message.style.color =
                "#ff5c5c";

        }

        return;
    }


    // ========================================
    // VALIDATE PERMISSION
    // ========================================

    if (
        permission !== "view" &&
        permission !== "download"
    ) {

        if (message) {

            message.textContent =
                "❌ Invalid permission selected.";

            message.style.color =
                "#ff5c5c";

        }

        return;
    }


    // ========================================
    // VALIDATE FILE PATH
    // ========================================

    if (!window.selectedShareFile.path) {

        if (message) {

            message.textContent =
                "❌ File path is missing.";

            message.style.color =
                "#ff5c5c";

        }

        return;
    }


    // ========================================
    // SHOW LOADING
    // ========================================

    if (message) {

        message.textContent =
            "🔄 Sharing file...";

        message.style.color =
            "#00e5ff";

    }


    // ========================================
    // INSERT SHARE RECORD
    // ========================================

    try {

        const {
            error
        } =
            await supabaseClient
                .from("file_shares")
                .insert([
                    {
                        file_path:
                            window.selectedShareFile.path,

                        shared_with_email:
                            email,

                        permission:
                            permission
                    }
                ]);


        // ========================================
        // DATABASE ERROR
        // ========================================

        if (error) {

            console.error(
                "❌ Share Error:",
                error
            );


            if (message) {

                message.textContent =
                    "❌ Sharing failed: " +
                    error.message;

                message.style.color =
                    "#ff5c5c";

            }

            return;
        }


        // ========================================
        // SUCCESS
        // ========================================

        console.log(
            "✅ File shared successfully"
        );


        if (message) {

            message.textContent =
                "✅ File shared successfully!";

            message.style.color =
                "#35e28a";

        }


        // ========================================
        // CLOSE AFTER SUCCESS
        // ========================================

        setTimeout(
            function () {

                closeShareModal();

            },
            1500
        );


    } catch (error) {

        console.error(
            "❌ Unexpected Share Error:",
            error
        );


        if (message) {

            message.textContent =
                "❌ Something went wrong.";

            message.style.color =
                "#ff5c5c";

        }

    }
}


// ========================================
// CLICK OUTSIDE MODAL
// ========================================

window.addEventListener(
    "click",
    function (event) {

        const modal =
            document.getElementById("shareModal");


        if (
            modal &&
            event.target === modal
        ) {

            closeShareModal();

        }

    }
);


console.log(
    "✅ Share functionality loaded"
);