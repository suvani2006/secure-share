const fileInput = document.getElementById("fileInput");
const dropArea = document.getElementById("drop-area");
const statusText = document.getElementById("statusText");

dropArea.addEventListener("click", () => {
    fileInput.click();
});

fileInput.addEventListener("change", () => {

    if(fileInput.files.length>0){

        statusText.innerHTML =
        "Selected : " + fileInput.files[0].name;

    }

});

dropArea.addEventListener("dragover",(e)=>{

e.preventDefault();

});

dropArea.addEventListener("drop",(e)=>{

e.preventDefault();

const file=e.dataTransfer.files[0];

statusText.innerHTML="Selected : "+file.name;

});