const SUPABASE_URL = "https://mlbktakryamamkstqwkw.supabase.co";

const SUPABASE_KEY = "sb_publishable_tk57e3w_rI6LaHFRL7ZRWg_x4uy1YMz";

const supabaseClient = supabase.createClient(
    SUPABASE_URL,
    SUPABASE_KEY
);

console.log("Supabase Connected");