// Secure File Vault - Shared File Page

const STORAGE_BUCKET = "files";

let sharedFileData = null;
let sharedFileBlob = null;

// ==========================================
// PAGE INITIALIZATION
// ==========================================

document.addEventListener("DOMContentLoaded", async () => {
    console.log("🔐 Shared file page loading...");

    try {
        const { data: { user }, error } =
            await supabaseClient.auth.getUser();

        if (error || !user) {
            showError(
                "🔐 Login required",
                "Please log in to your Secure File Vault account to access this shared file."
            );
            return;
        }

        await loadSharedFile();

    } catch (error) {
        console.error("❌ Shared page error:", error);

        showError(
            "❌ Unable to open file",
            error.message || "Something went wrong."
        );
    }
});


// ==========================================
// GET SHARE ID FROM URL
// ==========================================

function getShareId() {

    const params = new URLSearchParams(
        window.location.search
    );

    return params.get("share");
}


// ==========================================
// LOAD SHARED FILE
// ==========================================

async function loadSharedFile() {

    const shareId = getShareId();

    console.log("🔗 Share ID:", shareId);

    if (!shareId) {
        throw new Error(
            "Invalid secure sharing link."
        );
    }

    // Get logged-in user
    const {
        data: { user },
        error: userError
    } = await supabaseClient.auth.getUser();

    if (userError || !user) {
        throw new Error(
            "User authentication required."
        );
    }

    console.log("👤 Receiver:", user.email);


    // ==========================================
    // GET SHARE RECORD
    // ==========================================

    const {
        data: share,
        error: shareError
    } = await supabaseClient
        .from("file_shares")
        .select("*")
        .eq("id", shareId)
        .maybeSingle();


    if (shareError) {
        throw new Error(
            "Unable to verify shared file: " +
            shareError.message
        );
    }


    if (!share) {
        throw new Error(
            "This secure share does not exist or is no longer available."
        );
    }


    console.log("✅ Share record found:", share);


    // ==========================================
    // CHECK RECEIVER AUTHORIZATION
    // ==========================================

    const receiverEmail =
        (user.email || "").trim().toLowerCase();

    const sharedEmail =
        (share.shared_with_email || "")
            .trim()
            .toLowerCase();


    if (receiverEmail !== sharedEmail) {

        throw new Error(
            "You are not authorized to access this shared file."
        );
    }


    // ==========================================
    // CHECK WRAPPED KEY
    // ==========================================

    if (!share.wrapped_key) {

        showPendingMessage();

        return;
    }


    // ==========================================
    // FILE INFORMATION
    // ==========================================

    sharedFileData = share;

    const fileName =
        getFileNameFromPath(share.file_path);

    document.getElementById("fileName").textContent =
        fileName;

    document.getElementById("filePermission").textContent =
        "Permission: " +
        (share.permission || "view");


    // ==========================================
    // DOWNLOAD PERMISSION
    // ==========================================

    const downloadButton =
        document.getElementById("downloadButton");


    if (
        String(share.permission).toLowerCase()
        !== "download"
    ) {

        downloadButton.style.display =
            "none";
    }


    // ==========================================
    // DECRYPT FILE
    // ==========================================

    await decryptAndPreviewSharedFile(
        share
    );


    document.getElementById(
        "loadingMessage"
    ).style.display = "none";


    document.getElementById(
        "fileContent"
    ).style.display = "block";


    console.log(
        "🎉 Shared file loaded successfully."
    );
}


// ==========================================
// DECRYPT + PREVIEW
// ==========================================

async function decryptAndPreviewSharedFile(
    share
) {

    console.log(
        "🔐 Starting secure file decryption..."
    );


    if (!share.key_id) {
        throw new Error(
            "Encryption key information is missing."
        );
    }


    if (!share.wrapped_key) {
        throw new Error(
            "Secure encryption key has not been transferred yet."
        );
    }


    // ==========================================
    // GET RECEIVER PRIVATE KEY
    // ==========================================

    const privateKeyBase64 =
        await getStoredPrivateSharingKey();


    if (!privateKeyBase64) {

        throw new Error(
            "Secure sharing key is not available on this device. Please log in again on the device where your Secure File Vault account is configured."
        );
    }


    // ==========================================
    // UNWRAP AES KEY
    // ==========================================

    console.log(
        "🔓 Unwrapping file encryption key..."
    );


    const aesKeyBase64 =
        await unwrapAESKeyFromSharing(
            share.wrapped_key,
            privateKeyBase64
        );


    if (!aesKeyBase64) {
        throw new Error(
            "Unable to recover the file encryption key."
        );
    }


    console.log(
        "✅ AES encryption key recovered."
    );


    // ==========================================
    // DOWNLOAD ENCRYPTED FILE
    // ==========================================

    console.log(
        "📥 Downloading encrypted file..."
    );


    const {
        data: encryptedBlob,
        error: downloadError
    } = await supabaseClient
        .storage
        .from(STORAGE_BUCKET)
        .download(share.file_path);


    if (downloadError) {

        throw new Error(
            "Unable to access encrypted file: " +
            downloadError.message
        );
    }


    if (!encryptedBlob) {
        throw new Error(
            "Encrypted file was not found."
        );
    }


    console.log(
        "✅ Encrypted file downloaded."
    );


    // ==========================================
    // DECRYPT
    // ==========================================

    sharedFileBlob =
        await decryptBlobWithBase64Key(
            encryptedBlob,
            aesKeyBase64
        );


    if (!sharedFileBlob) {
        throw new Error(
            "File decryption failed."
        );
    }


    console.log(
        "✅ File decrypted successfully."
    );


    // ==========================================
    // PREVIEW
    // ==========================================

    showFilePreview(
        sharedFileBlob,
        getFileNameFromPath(share.file_path)
    );
}


// ==========================================
// GET STORED PRIVATE SHARING KEY
// ==========================================

async function getStoredPrivateSharingKey() {

    try {

        // Preferred method from encryption.js
        if (
            typeof getEncryptionKey ===
            "function"
        ) {
            try {

                const stored =
                    await getEncryptionKey(
                        "sharing_private_key"
                    );

                if (stored) {
                    return stored;
                }

            } catch (error) {
                console.log(
                    "ℹ️ Stored private key not found through getEncryptionKey."
                );
            }
        }


        // Direct IndexedDB fallback
        const db =
            await openSecureFileVaultDB();


        return await new Promise(
            (resolve) => {

                const transaction =
                    db.transaction(
                        "encryptionKeys",
                        "readonly"
                    );

                const store =
                    transaction.objectStore(
                        "encryptionKeys"
                    );


                const request =
                    store.get(
                        "sharing_private_key"
                    );


                request.onsuccess = () => {

                    if (
                        request.result &&
                        request.result.value
                    ) {

                        resolve(
                            request.result.value
                        );

                    } else {

                        resolve(null);
                    }
                };


                request.onerror = () => {
                    resolve(null);
                };
            }
        );

    } catch (error) {

        console.error(
            "❌ Private key retrieval failed:",
            error
        );

        return null;
    }
}


// ==========================================
// OPEN INDEXEDDB
// ==========================================

function openSecureFileVaultDB() {

    return new Promise(
        (resolve, reject) => {

            const request =
                indexedDB.open(
                    "SecureFileVaultDB"
                );


            request.onsuccess = () => {
                resolve(request.result);
            };


            request.onerror = () => {
                reject(
                    request.error ||
                    new Error(
                        "Unable to open secure storage."
                    )
                );
            };
        }
    );
}


// ==========================================
// DECRYPT BLOB WITH AES KEY
// ==========================================

async function decryptBlobWithBase64Key(
    encryptedBlob,
    keyBase64
) {

    const combinedBuffer =
        await encryptedBlob.arrayBuffer();


    const combinedBytes =
        new Uint8Array(combinedBuffer);


    if (combinedBytes.length < 13) {

        throw new Error(
            "Encrypted file data is invalid."
        );
    }


    // First 12 bytes = AES-GCM IV
    const iv =
        combinedBytes.slice(0, 12);


    // Remaining bytes = ciphertext
    const ciphertext =
        combinedBytes.slice(12);


    // Convert Base64 → bytes
    const binaryString =
        atob(keyBase64);


    const keyBytes =
        new Uint8Array(
            binaryString.length
        );


    for (
        let i = 0;
        i < binaryString.length;
        i++
    ) {

        keyBytes[i] =
            binaryString.charCodeAt(i);
    }


    // Import AES-256 key
    const cryptoKey =
        await crypto.subtle.importKey(
            "raw",
            keyBytes,
            {
                name: "AES-GCM"
            },
            false,
            ["decrypt"]
        );


    // Decrypt
    const decryptedBuffer =
        await crypto.subtle.decrypt(
            {
                name: "AES-GCM",
                iv: iv
            },
            cryptoKey,
            ciphertext
        );


    return new Blob(
        [decryptedBuffer]
    );
}


// ==========================================
// SHOW FILE PREVIEW
// ==========================================

function showFilePreview(
    blob,
    fileName
) {

    const previewArea =
        document.getElementById(
            "previewArea"
        );


    previewArea.innerHTML = "";


    const extension =
        fileName
            .split(".")
            .pop()
            .toLowerCase();


    const objectUrl =
        URL.createObjectURL(blob);


    // IMAGE
    if (
        [
            "jpg",
            "jpeg",
            "png",
            "gif",
            "webp",
            "jfif",
            "bmp"
        ].includes(extension)
    ) {

        const image =
            document.createElement("img");

        image.src =
            objectUrl;

        image.alt =
            fileName;

        previewArea.appendChild(
            image
        );

        return;
    }


    // VIDEO
    if (
        [
            "mp4",
            "webm",
            "ogg",
            "mov"
        ].includes(extension)
    ) {

        const video =
            document.createElement("video");

        video.src =
            objectUrl;

        video.controls = true;

        previewArea.appendChild(
            video
        );

        return;
    }


    // AUDIO
    if (
        [
            "mp3",
            "wav",
            "ogg",
            "m4a"
        ].includes(extension)
    ) {

        const audio =
            document.createElement("audio");

        audio.src =
            objectUrl;

        audio.controls = true;

        previewArea.appendChild(
            audio
        );

        return;
    }


    // PDF
    if (extension === "pdf") {

        const iframe =
            document.createElement("iframe");

        iframe.src =
            objectUrl;

        previewArea.appendChild(
            iframe
        );

        return;
    }


    // TEXT
    if (
        [
            "txt",
            "html",
            "css",
            "js",
            "json"
        ].includes(extension)
    ) {

        blob.text().then(
            (text) => {

                const pre =
                    document.createElement(
                        "pre"
                    );

                pre.style.textAlign =
                    "left";

                pre.style.whiteSpace =
                    "pre-wrap";

                pre.textContent =
                    text;

                previewArea.appendChild(
                    pre
                );
            }
        );

        return;
    }


    // OTHER FILE TYPES
    const message =
        document.createElement("p");

    message.textContent =
        "Preview is not available for this file type. You can download the file.";

    previewArea.appendChild(
        message
    );
}


// ==========================================
// DOWNLOAD SHARED FILE
// ==========================================

async function downloadSharedFile() {

    try {

        if (!sharedFileData) {
            throw new Error(
                "Shared file information is not available."
            );
        }


        if (
            String(
                sharedFileData.permission
            ).toLowerCase()
            !== "download"
        ) {

            alert(
                "Download permission is not available for this file."
            );

            return;
        }


        if (!sharedFileBlob) {

            throw new Error(
                "File is not ready for download."
            );
        }


        const fileName =
            getFileNameFromPath(
                sharedFileData.file_path
            );


        const objectUrl =
            URL.createObjectURL(
                sharedFileBlob
            );


        const link =
            document.createElement("a");

        link.href =
            objectUrl;

        link.download =
            fileName;


        document.body.appendChild(
            link
        );

        link.click();

        link.remove();


        setTimeout(() => {
            URL.revokeObjectURL(
                objectUrl
            );
        }, 1000);


        console.log(
            "⬇️ File downloaded:",
            fileName
        );

    } catch (error) {

        console.error(
            "❌ Download failed:",
            error
        );

        showStatus(
            "❌ Download failed: " +
            error.message
        );
    }
}


// ==========================================
// PENDING SHARE
// ==========================================

function showPendingMessage() {

    document.getElementById(
        "loadingMessage"
    ).innerHTML = `
        <div style="font-size:45px;">📨</div>

        <h2>Secure File Pending</h2>

        <p>
            The sender has shared a file with you,
            but the secure encryption key has not
            been transferred yet.
        </p>

        <p>
            Please wait until the sender completes
            the secure key transfer.
        </p>
    `;
}


// ==========================================
// ERROR MESSAGE
// ==========================================

function showError(
    title,
    message
) {

    const loading =
        document.getElementById(
            "loadingMessage"
        );


    loading.style.display =
        "block";


    loading.innerHTML = `
        <div style="font-size:45px;">🔒</div>

        <h2>${escapeHtml(title)}</h2>

        <p>${escapeHtml(message)}</p>

        <button
            type="button"
            onclick="window.location.href='login.html'"
            style="margin-top:20px;"
        >
            Go to Login
        </button>
    `;
}


// ==========================================
// STATUS MESSAGE
// ==========================================

function showStatus(message) {

    const status =
        document.getElementById(
            "statusMessage"
        );


    if (!status) {
        return;
    }


    status.textContent =
        message;


    status.style.display =
        "block";
}


// ==========================================
// FILE NAME
// ==========================================

function getFileNameFromPath(
    filePath
) {

    if (!filePath) {
        return "Shared File";
    }


    const parts =
        filePath.split("/");


    return decodeURIComponent(
        parts[parts.length - 1]
    ).replace(
        /^\d+_/,
        ""
    );
}


// ==========================================
// HTML ESCAPE
// ==========================================

function escapeHtml(value) {

    return String(value)
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}