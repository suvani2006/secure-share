console.log("🔐 SIGNUP JS LOADED");

document
    .getElementById("signupBtn")
    .addEventListener("click", async function () {

        const fullName =
            document.getElementById("fullName").value.trim();

        const email =
            document.getElementById("email").value.trim().toLowerCase();

        const password =
            document.getElementById("password").value;

        const confirmPassword =
            document.getElementById("confirmPassword").value;

        // Validate full name
        if (fullName === "") {
            alert("Please enter your full name.");
            return;
        }

        // Validate email
        if (email === "") {
            alert("Please enter your email.");
            return;
        }

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email)) {
            alert("Please enter a valid email address.");
            return;
        }

        // Validate password
        if (password === "") {
            alert("Please enter a password.");
            return;
        }

        if (password.length < 6) {
            alert("Password must be at least 6 characters.");
            return;
        }

        // Confirm password
        if (password !== confirmPassword) {
            alert("Passwords do not match.");
            return;
        }

        try {

            console.log("🔐 Creating account...");

            const {
                data,
                error
            } = await supabaseClient.auth.signUp({
                email: email,
                password: password,
                options: {
                    data: {
                        full_name: fullName
                    }
                }
            });

            if (error) {
                console.error("❌ Signup Error:", error);
                alert("❌ Signup failed: " + error.message);
                return;
            }

            console.log("✅ Account created:", data);

            /*
             * Supabase may require email confirmation.
             * Therefore, the RSA sharing key setup will be completed
             * after the user successfully logs in.
             */

            alert(
                "✅ Account created successfully!\n\n" +
                "Please check your email if email confirmation is required, " +
                "then login to Secure File Vault Pro."
            );

            window.location.href = "login.html";

        } catch (error) {

            console.error("❌ Unexpected Signup Error:", error);

            alert(
                "❌ Something went wrong during account creation."
            );
        }

    });