// ========================================
// SECURE FILE VAULT PRO
// upload.js
// ========================================

console.log("📤 upload.js loaded");


// ========================================
// UPLOAD FILE
// ========================================

async function uploadFile() {

    console.log("🚀 Upload started");


    // ========================================
    // GET FILE INPUT
    // ========================================

    const fileInput =
        document.getElementById("fileInput");


    // ========================================
    // GET / CREATE MESSAGE
    // ========================================

    let message =
        document.getElementById("message");


    if (!message) {

        message =
            document.createElement("p");

        message.id =
            "message";

        message.style.marginTop =
            "15px";


        const uploadSection =
            document.querySelector(
                ".upload-section"
            );


        if (uploadSection) {

            uploadSection.appendChild(
                message
            );

        } else {

            document.body.appendChild(
                message
            );
        }
    }


    // ========================================
    // CHECK FILE INPUT
    // ========================================

    if (!fileInput) {

        console.error(
            "❌ fileInput not found"
        );

        message.innerHTML =
            "❌ File input not found.";

        return;
    }


    // ========================================
    // GET SELECTED FILE
    // ========================================

    const file =
        fileInput.files[0];


    if (!file) {

        console.error(
            "❌ No file selected"
        );

        message.innerHTML =
            "❌ Please select a file.";

        return;
    }


    console.log(
        "📄 File selected:",
        file.name
    );

    console.log(
        "📦 File size:",
        file.size,
        "bytes"
    );


    // ========================================
    // CHECK SUPABASE
    // ========================================

    if (
        typeof supabaseClient ===
        "undefined" ||
        !supabaseClient
    ) {

        console.error(
            "❌ supabaseClient not available"
        );

        message.innerHTML =
            "❌ Supabase is not connected.";

        return;
    }


    console.log(
        "✅ Supabase client available"
    );


    // ========================================
    // CHECK ENCRYPTION FUNCTION
    // ========================================

    if (
        typeof encryptFile !==
        "function"
    ) {

        console.error(
            "❌ encryptFile() not found"
        );

        message.innerHTML =
            "❌ Encryption module not loaded.";

        return;
    }


    console.log(
        "✅ encryptFile() available"
    );


    try {

        // ====================================
        // STEP 1
        // ENCRYPT FILE
        // ====================================

        message.innerHTML =
            "🔐 Encrypting file...";


        console.log(
            "🔐 Encrypting..."
        );


        const encryptedFile =
            await encryptFile(file);


        if (!encryptedFile) {

            throw new Error(
                "Encryption returned empty data"
            );
        }


        console.log(
            "✅ Encryption successful"
        );


        // ====================================
        // STEP 2
        // CREATE BLOB
        // ====================================

        const encryptedBlob =
            new Blob(
                [encryptedFile],
                {
                    type:
                        "application/octet-stream"
                }
            );


        console.log(
            "📦 Encrypted blob size:",
            encryptedBlob.size,
            "bytes"
        );


        // ====================================
        // STEP 3
        // CREATE UNIQUE FILE NAME
        // ====================================

        const safeFileName =
            file.name.replace(
                /[^a-zA-Z0-9._-]/g,
                "_"
            );


        const fileName =
            Date.now() +
            "-" +
            crypto.randomUUID() +
            "-" +
            safeFileName;


        console.log(
            "📝 Storage file name:",
            fileName
        );


        // ====================================
        // STEP 4
        // UPLOAD TO SUPABASE STORAGE
        // ====================================

        message.innerHTML =
            "☁️ Uploading to Secure Vault...";


        console.log(
            "☁️ Uploading to bucket: files"
        );


        const {
            data: storageData,
            error: storageError
        } =
            await supabaseClient
                .storage
                .from("files")
                .upload(
                    fileName,
                    encryptedBlob,
                    {
                        contentType:
                            "application/octet-stream",

                        upsert:
                            false
                    }
                );


        console.log(
            "📦 Storage data:",
            storageData
        );


        console.log(
            "📦 Storage error:",
            storageError
        );


        // ====================================
        // STORAGE ERROR
        // ====================================

        if (storageError) {

            console.error(
                "❌ STORAGE ERROR:",
                storageError
            );


            message.innerHTML =
                "❌ Storage Upload Failed: " +
                storageError.message;


            return;
        }


        // ====================================
        // CHECK STORAGE PATH
        // ====================================

        if (
            !storageData ||
            !storageData.path
        ) {

            console.error(
                "❌ Storage path not returned"
            );


            message.innerHTML =
                "❌ Upload failed: storage path missing.";

            return;
        }


        console.log(
            "✅ File uploaded to Storage"
        );


        console.log(
            "📂 Storage path:",
            storageData.path
        );


        // ====================================
        // STEP 5
        // SAVE DATABASE RECORD
        // ====================================

        message.innerHTML =
            "💾 Saving file details...";


        console.log(
            "💾 Saving metadata to files table..."
        );


        const {
            data: databaseData,
            error: databaseError
        } =
            await supabaseClient
                .from("files")
                .insert([
                    {

                        file_name:
                            file.name,

                        file_path:
                            storageData.path,

                        file_size:
                            file.size,

                        encryption_status:
                            "AES-256-GCM Encrypted",

                        decryption_status:
                            "Not Decrypted"

                    }
                ])
                .select();


        console.log(
            "💾 Database data:",
            databaseData
        );


        console.log(
            "💾 Database error:",
            databaseError
        );


        // ====================================
        // DATABASE ERROR
        // ====================================

        if (databaseError) {

            console.error(
                "❌ DATABASE ERROR:",
                databaseError
            );


            message.innerHTML =
                "❌ Database save failed: " +
                databaseError.message;


            // =================================
            // CLEANUP STORAGE FILE
            // =================================

            console.log(
                "🧹 Removing uploaded file..."
            );


            const {
                error: cleanupError
            } =
                await supabaseClient
                    .storage
                    .from("files")
                    .remove([
                        storageData.path
                    ]);


            if (cleanupError) {

                console.error(
                    "⚠️ Cleanup failed:",
                    cleanupError
                );

            } else {

                console.log(
                    "✅ Uploaded file removed"
                );
            }


            return;
        }


        // ====================================
        // SUCCESS
        // ====================================

        console.log(
            "🎉 FILE UPLOAD SUCCESSFUL"
        );


        message.innerHTML =
            "✅ File uploaded successfully!";


        // ====================================
        // CLEAR FILE INPUT
        // ====================================

        fileInput.value = "";


        // ====================================
        // REFRESH FILE LIST
        // ====================================

        if (
            typeof loadFiles ===
            "function"
        ) {

            console.log(
                "🔄 Refreshing file list..."
            );


            await loadFiles();


            console.log(
                "✅ File list refreshed"
            );
        }


    } catch (error) {

        // ====================================
        // FINAL ERROR
        // ====================================

        console.error(
            "🔥 UPLOAD ERROR:",
            error
        );


        message.innerHTML =
            "❌ Upload failed: " +
            error.message;
    }
}


// ========================================
// CONNECT UPLOAD BUTTON
// ========================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        console.log(
            "📄 DOM loaded"
        );


        const uploadButton =
            document.getElementById(
                "uploadButton"
            );


        if (uploadButton) {

            uploadButton.addEventListener(
                "click",
                uploadFile
            );


            console.log(
                "✅ Upload button connected"
            );

        } else {

            console.warn(
                "⚠️ uploadButton not found"
            );
        }

    }
);


console.log(
    "✅ upload.js loaded successfully"
);