console.log("🔗 SHARED FILES JS LOADED");

// ========================================
// LOAD SHARED FILES
// ========================================

async function loadSharedFiles() {

    console.log("🔄 Loading shared files...");

    const sharedFilesList =
        document.getElementById("sharedFilesList");

    if (!sharedFilesList) {

        console.error(
            "❌ sharedFilesList element not found"
        );

        return;
    }

    sharedFilesList.innerHTML =
        "<p>🔄 Loading shared files...</p>";

    try {

        // ========================================
        // GET SHARED FILE RECORDS
        // ========================================

        const {
            data: shares,
            error: shareError
        } = await supabaseClient
            .from("file_shares")
            .select("*")
            .order(
                "created_at",
                {
                    ascending: false
                }
            );


        // ========================================
        // DATABASE ERROR
        // ========================================

        if (shareError) {

            console.error(
                "❌ Shared Files Error:",
                shareError
            );

            sharedFilesList.innerHTML =
                "<p>❌ Failed to load shared files: " +
                shareError.message +
                "</p>";

            return;
        }


        console.log(
            "📦 Shared records:",
            shares
        );


        // ========================================
        // NO SHARED FILES
        // ========================================

        if (!shares || shares.length === 0) {

            sharedFilesList.innerHTML =
                "<p>📁 No files have been shared yet.</p>";

            return;
        }


        // ========================================
        // GET FILE PATHS
        // ========================================

        const filePaths =
            shares
                .map(function (share) {

                    return share.file_path;

                })
                .filter(function (path) {

                    return path;

                });


        // ========================================
        // GET FILE INFORMATION
        // ========================================

        let files = [];

        if (filePaths.length > 0) {

            const {
               
    data: fileData,
    error: fileError
} = await supabaseClient
    .from("files")
    .select("*");


            if (fileError) {

                console.error(
                    "❌ File Information Error:",
                    fileError
                );

            } else {

                files =
                    fileData || [];

            }
        }


        // ========================================
        // CLEAR LIST
        // ========================================

        sharedFilesList.innerHTML = "";


        // ========================================
        // CREATE SHARED FILE CARDS
        // ========================================

        shares.forEach(function (share) {

            // ====================================
            // FIND MATCHING FILE
            // ====================================

            const matchingFile =
                files.find(function (file) {

                    return (
                        file.file_path ===
                        share.file_path
                    );

                });


            // ====================================
            // FILE NAME
            // ====================================

            const fileName =
                matchingFile?.file_name ||
                getFileNameFromPath(
                    share.file_path
                );


            // ====================================
            // ENCRYPTION STATUS
            // ====================================

            const encryptionStatus =
                matchingFile?.encrypt_status ||
                "Encrypted";


            // ====================================
            // PERMISSION
            // ====================================

            const permission =
                share.permission ||
                "view";


            // ====================================
            // CARD
            // ====================================

            const card =
                document.createElement("div");

            card.className =
                "shared-file-card";


            // ====================================
            // TITLE
            // ====================================

            const title =
                document.createElement("h3");

            title.textContent =
                "📄 " + fileName;

            title.title =
                fileName;


            // ====================================
            // ENCRYPTION BADGE
            // ====================================

            const badge =
                document.createElement("span");

            badge.className =
                "encryption-badge";

            badge.textContent =
                "🔐 " + encryptionStatus;


            // ====================================
            // FILE PATH
            // ====================================

            const pathText =
                document.createElement("p");

            pathText.textContent =
                "📁 Path: " +
                (
                    share.file_path ||
                    "Unavailable"
                );


            // ====================================
            // SHARED WITH
            // ====================================

            const sharedWithText =
                document.createElement("p");

            sharedWithText.textContent =
                "👤 Shared with: " +
                (
                    share.shared_with_email ||
                    "Unknown"
                );


            // ====================================
            // PERMISSION
            // ====================================

            const permissionText =
                document.createElement("p");

            if (permission === "download") {

                permissionText.textContent =
                    "🔓 Permission: View & Download";

            } else {

                permissionText.textContent =
                    "👁️ Permission: View Only";

            }


            // ====================================
            // SHARED DATE
            // ====================================

            const dateText =
                document.createElement("p");

            let sharedDate =
                "Date unavailable";

            if (share.created_at) {

                const date =
                    new Date(
                        share.created_at
                    );

                if (!isNaN(date.getTime())) {

                    sharedDate =
                        date.toLocaleString();

                }

            }

            dateText.textContent =
                "📅 Shared: " +
                sharedDate;


            // ====================================
            // BUTTON CONTAINER
            // ====================================

            const buttonContainer =
                document.createElement("div");

            buttonContainer.className =
                "shared-file-actions";


            // ====================================
            // VIEW BUTTON
            // ====================================

            const viewButton =
                document.createElement("button");

            viewButton.type =
                "button";

            viewButton.textContent =
                "👁️ View";


            viewButton.addEventListener(
                "click",
                function () {

                    console.log(
                        "👁️ View shared file:",
                        fileName
                    );

                    viewSharedFile(
                        share.file_path,
                        fileName
                    );

                }
            );


            // ====================================
            // DOWNLOAD BUTTON
            // ====================================

            const downloadButton =
                document.createElement("button");

            downloadButton.type =
                "button";

            downloadButton.textContent =
                "📥 Download";


            // ====================================
            // DOWNLOAD PERMISSION
            // ====================================

            if (permission === "download") {

                downloadButton.disabled =
                    false;

                downloadButton.addEventListener(
                    "click",
                    function () {

                        console.log(
                            "📥 Download shared file:",
                            fileName
                        );

                        downloadSharedFile(
                            share.file_path,
                            fileName
                        );

                    }
                );

            } else {

                downloadButton.disabled =
                    true;

                downloadButton.title =
                    "Download permission was not granted";

            }


            // ====================================
            // ADD BUTTONS
            // ====================================

            buttonContainer.appendChild(
                viewButton
            );

            buttonContainer.appendChild(
                downloadButton
            );


            // ====================================
            // ADD ELEMENTS TO CARD
            // ====================================

            card.appendChild(title);

            card.appendChild(badge);

            card.appendChild(permissionText);

            card.appendChild(sharedWithText);

            card.appendChild(dateText);

            card.appendChild(pathText);

            card.appendChild(buttonContainer);


            // ====================================
            // ADD CARD TO PAGE
            // ====================================

            sharedFilesList.appendChild(card);

        });


        // ========================================
        // FINAL CHECK
        // ========================================

        console.log(
            "✅ Shared files displayed:",
            shares.length
        );


    } catch (error) {

        console.error(
            "❌ loadSharedFiles() Error:",
            error
        );

        sharedFilesList.innerHTML =
            "<p>❌ Something went wrong.</p>";

    }

}


// ========================================
// GET FILE NAME FROM PATH
// ========================================

function getFileNameFromPath(filePath) {

    if (!filePath) {

        return "Shared File";

    }

    const parts =
        filePath.split("/");

    return (
        parts[parts.length - 1] ||
        "Shared File"
    );

}


// ========================================
// VIEW SHARED FILE
// ========================================

async function viewSharedFile(
    filePath,
    fileName
) {

    try {

        if (!filePath) {

            alert(
                "❌ File path is missing."
            );

            return;
        }


        console.log(
            "👁️ Opening shared file:",
            filePath
        );


        const {
            data,
            error
        } =
            await supabaseClient.storage
                .from("files")
                .download(
                    filePath
                );


        if (error) {

            console.error(
                "❌ View Error:",
                error
            );

            alert(
                "❌ Unable to view file: " +
                error.message
            );

            return;
        }


        if (!data) {

            alert(
                "❌ No file data received."
            );

            return;
        }


        const url =
            URL.createObjectURL(
                data
            );


        window.open(
            url,
            "_blank"
        );


        setTimeout(
            function () {

                URL.revokeObjectURL(
                    url
                );

            },
            60000
        );


    } catch (error) {

        console.error(
            "❌ View Shared File Error:",
            error
        );

        alert(
            "❌ Unable to view shared file."
        );

    }

}


// ========================================
// DOWNLOAD SHARED FILE
// ========================================

async function downloadSharedFile(
    filePath,
    fileName
) {

    try {

        console.log(
            "📥 Downloading shared file:",
            filePath
        );


        if (!filePath) {

            alert(
                "❌ File path is missing."
            );

            return;
        }


        const {
            data,
            error
        } =
            await supabaseClient.storage
                .from("files")
                .download(
                    filePath
                );


        if (error) {

            console.error(
                "❌ Download Error:",
                error
            );

            alert(
                "❌ Download failed: " +
                error.message
            );

            return;
        }


        if (!data) {

            alert(
                "❌ No file data received."
            );

            return;
        }


        const url =
            URL.createObjectURL(
                data
            );


        const link =
            document.createElement("a");

        link.href =
            url;

        link.download =
            fileName ||
            "shared-file";


        document.body.appendChild(
            link
        );

        link.click();

        link.remove();


        setTimeout(
            function () {

                URL.revokeObjectURL(
                    url
                );

            },
            1000
        );


        console.log(
            "✅ Shared file downloaded."
        );


    } catch (error) {

        console.error(
            "❌ Shared Download Error:",
            error
        );

        alert(
            "❌ Download failed."
        );

    }

}


// ========================================
// START
// ========================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        console.log(
            "🚀 Shared Files DOM Loaded"
        );

        loadSharedFiles();

    }
);