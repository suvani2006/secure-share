console.log("🔥 FETCH FILES JS LOADED - FINAL VERSION");

// ========================================
// LOAD FILES
// ========================================

async function loadFiles() {

    console.log("🔥 loadFiles() STARTED");

    const fileList =
        document.getElementById("fileList");

    if (!fileList) {

        console.error(
            "❌ fileList element not found"
        );

        return;
    }

    try {

        // ========================================
        // GET FILES FROM SUPABASE
        // ========================================

        const {
            data,
            error
        } = await supabaseClient
            .from("files")
            .select("*")
            .order(
                "created_at",
                {
                    ascending: false
                }
            );


        console.log(
            "📦 Files Data:",
            data
        );

        console.log(
            "❌ Database Error:",
            error
        );


        // ========================================
        // CHECK DATABASE ERROR
        // ========================================

        if (error) {

            console.error(
                "❌ Fetch Error:",
                error
            );

            fileList.innerHTML =
                "<p>❌ Failed to load files.</p>";

            return;
        }


        // ========================================
        // UPDATE FILE COUNT
        // ========================================

        const fileCount =
            document.getElementById(
                "fileCount"
            );

        if (fileCount) {

            fileCount.textContent =
                data
                    ? data.length
                    : 0;
        }


        // ========================================
        // CLEAR OLD FILES
        // ========================================

        fileList.innerHTML = "";


        // ========================================
        // NO FILES
        // ========================================

        if (
            !data ||
            data.length === 0
        ) {

            fileList.innerHTML =
                "<p>📁 No files uploaded yet.</p>";

            return;
        }


        // ========================================
        // CREATE FILE CARDS
        // ========================================

        data.forEach(
            function (file) {

                // ====================================
                // FILE INFORMATION
                // ====================================

                const fileName =
                    file.file_name ||
                    "Unnamed File";


                const filePath =
                    file.file_path ||
                    "";


                const encryptionStatus =
                    file.encryption_status ||
                    "AES-256-GCM Encrypted";


                const fileSize =
                    file.file_size ||
                    0;


                // ====================================
                // CREATE CARD
                // ====================================

                const card =
                    document.createElement(
                        "div"
                    );

                card.className =
                    "file-card";


                // ====================================
                // FILE TITLE
                // ====================================

                const title =
                    document.createElement(
                        "h3"
                    );

                title.textContent =
                    "📄 " + fileName;

                title.title =
                    fileName;


                // ====================================
                // ENCRYPTION BADGE
                // ====================================

                const badge =
                    document.createElement(
                        "span"
                    );

                badge.className =
                    "encryption-badge";

                badge.textContent =
                    "🔐 " +
                    encryptionStatus;


                // ====================================
                // FILE SIZE
                // ====================================

                const sizeText =
                    document.createElement(
                        "p"
                    );

                sizeText.textContent =
                    "📦 Size: " +
                    formatFileSize(
                        fileSize
                    );


                // ====================================
                // UPLOAD DATE
                // ====================================

                const dateText =
                    document.createElement(
                        "p"
                    );

                let fileDate =
                    "Date unavailable";


                if (file.created_at) {

                    const date =
                        new Date(
                            file.created_at
                        );


                    if (
                        !isNaN(
                            date.getTime()
                        )
                    ) {

                        fileDate =
                            date.toLocaleString();
                    }
                }


                dateText.textContent =
                    "📅 Uploaded: " +
                    fileDate;


                // ====================================
                // FILE PATH
                // ====================================

                const pathText =
                    document.createElement(
                        "p"
                    );

                pathText.textContent =
                    "📁 Path: " +
                    (
                        filePath ||
                        "Unavailable"
                    );


                // ====================================
                // BUTTON CONTAINER
                // ====================================

                const buttonContainer =
                    document.createElement(
                        "div"
                    );

                buttonContainer.className =
                    "file-actions";


                // ====================================
                // PREVIEW BUTTON
                // ====================================

                const previewButton =
                    document.createElement(
                        "button"
                    );

                previewButton.type =
                    "button";

                previewButton.textContent =
                    "👁️ Preview";


                previewButton.addEventListener(
                    "click",
                    function () {

                        console.log(
                            "👁️ Preview clicked:",
                            fileName
                        );


                        if (!filePath) {

                            alert(
                                "❌ File path is missing."
                            );

                            return;
                        }


                        if (
                            typeof previewFile ===
                            "function"
                        ) {

                            previewFile(
                                filePath,
                                fileName
                            );

                        } else {

                            console.error(
                                "❌ previewFile() not found"
                            );

                            alert(
                                "❌ Preview function is not available."
                            );
                        }
                    }
                );


                // ====================================
                // DOWNLOAD BUTTON
                // ====================================

                const downloadButton =
                    document.createElement(
                        "button"
                    );

                downloadButton.type =
                    "button";

                downloadButton.textContent =
                    "📥 Decrypt & Download";


                downloadButton.addEventListener(
                    "click",
                    function () {

                        console.log(
                            "📥 Download clicked:",
                            fileName
                        );


                        if (!filePath) {

                            alert(
                                "❌ File path is missing."
                            );

                            return;
                        }


                        if (
                            typeof downloadFile ===
                            "function"
                        ) {

                            downloadFile(
                                filePath,
                                fileName
                            );

                        } else {

                            console.error(
                                "❌ downloadFile() not found"
                            );

                            alert(
                                "❌ Download function is not available."
                            );
                        }
                    }
                );


                // ====================================
                // SHARE BUTTON
                // ====================================

                const shareButton =
                    document.createElement(
                        "button"
                    );

                shareButton.type =
                    "button";

                shareButton.className =
                    "share-file-btn";

                shareButton.textContent =
                    "🔗 Share File";


                // ====================================
                // SHARE BUTTON CLICK
                // ====================================

                shareButton.addEventListener(
                    "click",
                    function () {

                        console.log(
                            "🔗 Share button clicked"
                        );


                        console.log(
                            "📄 File object:",
                            file
                        );


                        console.log(
                            "📁 File path:",
                            filePath
                        );


                        // =================================
                        // CHECK FILE PATH
                        // =================================

                        if (!filePath) {

                            alert(
                                "❌ File path is missing."
                            );

                            return;
                        }


                        // =================================
                        // CHECK SHARE FUNCTION
                        // =================================

                        if (
                            typeof openShareModal ===
                            "function"
                        ) {

                            console.log(
                                "🔗 Opening share modal for:",
                                fileName
                            );


                            openShareModal(
                                filePath,
                                fileName
                            );

                        } else {

                            console.error(
                                "❌ openShareModal() function not found"
                            );


                            alert(
                                "❌ Share system is not loaded."
                            );
                        }
                    }
                );


                // ====================================
                // ADD BUTTONS
                // ====================================

                buttonContainer.appendChild(
                    previewButton
                );


                buttonContainer.appendChild(
                    downloadButton
                );


                buttonContainer.appendChild(
                    shareButton
                );


                // ====================================
                // ADD CARD CONTENT
                // ====================================

                card.appendChild(
                    title
                );


                card.appendChild(
                    badge
                );


                card.appendChild(
                    sizeText
                );


                card.appendChild(
                    dateText
                );


                card.appendChild(
                    pathText
                );


                card.appendChild(
                    buttonContainer
                );


                // ====================================
                // ADD CARD TO FILE LIST
                // ====================================

                fileList.appendChild(
                    card
                );

            }
        );


        // ========================================
        // FINAL CHECK
        // ========================================

        console.log(
            "✅ Files displayed:",
            data.length
        );


        console.log(
            "🔗 Share buttons:",
            document.querySelectorAll(
                ".share-file-btn"
            ).length
        );

    } catch (error) {

        console.error(
            "❌ loadFiles() ERROR:",
            error
        );


        fileList.innerHTML =
            "<p>❌ Something went wrong.</p>";
    }
}


// ========================================
// FORMAT FILE SIZE
// ========================================

function formatFileSize(bytes) {

    if (
        !bytes ||
        bytes <= 0
    ) {

        return "Unknown";
    }


    const units = [
        "Bytes",
        "KB",
        "MB",
        "GB"
    ];


    let index =
        Math.floor(
            Math.log(bytes) /
            Math.log(1024)
        );


    if (index < 0) {

        index = 0;
    }


    if (
        index >=
        units.length
    ) {

        index =
            units.length - 1;
    }


    const size =
        bytes /
        Math.pow(
            1024,
            index
        );


    return (
        size.toFixed(2) +
        " " +
        units[index]
    );
}


// ========================================
// SEARCH FILES
// ========================================

function searchFiles() {

    const searchInput =
        document.getElementById(
            "searchFiles"
        );


    if (!searchInput) {

        return;
    }


    const searchText =
        searchInput.value
            .toLowerCase()
            .trim();


    const fileCards =
        document.querySelectorAll(
            ".file-card"
        );


    fileCards.forEach(
        function (card) {

            const title =
                card.querySelector(
                    "h3"
                );


            if (!title) {

                return;
            }


            const name =
                title.textContent
                    .toLowerCase();


            card.style.display =
                name.includes(
                    searchText
                )
                    ? ""
                    : "none";
        }
    );
}


// ========================================
// DOWNLOAD FILE
// ========================================

async function downloadFile(
    filePath,
    originalFileName
) {

    try {

        console.log(
            "📥 Download started:",
            filePath
        );


        // ====================================
        // CHECK PATH
        // ====================================

        if (!filePath) {

            alert(
                "❌ File path is missing."
            );

            return;
        }


        // ====================================
        // DOWNLOAD ENCRYPTED FILE
        // ====================================

        const {
            data,
            error
        } =
            await supabaseClient.storage
                .from("files")
                .download(
                    filePath
                );


        if (error) {

            console.error(
                "❌ Download Error:",
                error
            );


            alert(
                "❌ Download failed: " +
                error.message
            );

            return;
        }


        if (!data) {

            alert(
                "❌ No file data received."
            );

            return;
        }


        // ====================================
        // CONVERT TO ARRAY BUFFER
        // ====================================

        const encryptedData =
            await data.arrayBuffer();


        // ====================================
        // CHECK DECRYPTION FUNCTION
        // ====================================

        if (
            typeof decryptFile !==
            "function"
        ) {

            console.error(
                "❌ decryptFile() function not found"
            );


            alert(
                "❌ Decryption function is not available."
            );

            return;
        }


        // ====================================
        // DECRYPT
        // ====================================

        const decryptedData =
            await decryptFile(
                encryptedData
            );


        // ====================================
        // CREATE DOWNLOAD
        // ====================================

        const blob =
            new Blob([
                decryptedData
            ]);


        const url =
            URL.createObjectURL(
                blob
            );


        const link =
            document.createElement(
                "a"
            );


        link.href =
            url;


        link.download =
            originalFileName ||
            "downloaded-file";


        document.body.appendChild(
            link
        );


        link.click();


        link.remove();


        // ====================================
        // CLEAN URL
        // ====================================

        setTimeout(
            function () {

                URL.revokeObjectURL(
                    url
                );

            },
            1000
        );


        console.log(
            "✅ File downloaded successfully"
        );

    } catch (error) {

        console.error(
            "❌ Decrypt/Download Error:",
            error
        );


        alert(
            "❌ Decrypt/Download failed: " +
            error.message
        );
    }
}


// ========================================
// START
// ========================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        console.log(
            "🚀 Dashboard DOM Loaded"
        );


        loadFiles();

    }
);