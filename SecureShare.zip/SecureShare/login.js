console.log("🔐 LOGIN JS LOADED");

document
    .getElementById("loginBtn")
    .addEventListener("click", async function () {

        const email =
            document.getElementById("email").value.trim().toLowerCase();

        const password =
            document.getElementById("password").value;

        // ========================================
        // VALIDATION
        // ========================================

        if (email === "") {
            alert("Please enter your email.");
            return;
        }

        if (password === "") {
            alert("Please enter your password.");
            return;
        }

        // ========================================
        // SUPABASE LOGIN
        // ========================================

        try {

            const {
                data,
                error
            } = await supabaseClient.auth.signInWithPassword({
                email: email,
                password: password
            });

            if (error) {

                console.error(
                    "❌ Login Error:",
                    error
                );

                alert(
                    "❌ Login failed: " +
                    error.message
                );

                return;
            }

            // ========================================
            // LOGIN SUCCESS
            // ========================================

            console.log(
                "✅ Login successful:",
                data.user
            );

            // ========================================
            // SETUP SECURE SHARING KEY
            // ========================================

            try {

                console.log(
                    "🔐 Setting up secure sharing key..."
                );

                // Generate or retrieve local RSA key pair
                const sharingKeys =
                    await ensureLocalSharingKeyPair();

                if (!sharingKeys ||
                    !sharingKeys.publicKey) {

                    throw new Error(
                        "Public sharing key could not be generated."
                    );
                }

                console.log(
                    "✅ RSA sharing key ready."
                );

                // ========================================
                // SAVE PUBLIC KEY TO SUPABASE
                // ========================================

                const {
                    error: keyError
                } = await supabaseClient
                    .from("user_keys")
                    .upsert(
                        {
                            user_id: data.user.id,
                            email: email,
                            public_key: sharingKeys.publicKey
                        },
                        {
                            onConflict: "user_id"
                        }
                    );

                if (keyError) {

                    console.error(
                        "❌ Public key save error:",
                        keyError
                    );

                    throw new Error(
                        "Could not save secure sharing key: " +
                        keyError.message
                    );
                }

                console.log(
                    "✅ Public sharing key saved successfully."
                );

            } catch (sharingError) {

                console.error(
                    "❌ Secure sharing setup failed:",
                    sharingError
                );

                alert(
                    "⚠️ Login successful, but secure sharing setup failed.\n\n" +
                    sharingError.message
                );

                return;
            }

            // ========================================
            // FINAL LOGIN SUCCESS
            // ========================================

            alert(
                "✅ Login successful!\n\n" +
                "🔐 Secure sharing is ready."
            );

            window.location.href =
                "dashboard.html";

        } catch (error) {

            console.error(
                "❌ Unexpected Login Error:",
                error
            );

            alert(
                "❌ Something went wrong during login."
            );
        }

    });