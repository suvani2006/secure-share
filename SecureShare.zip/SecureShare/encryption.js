// ========================================
// SECURE FILE VAULT PRO
// encryption.js
// AES-256-GCM ENCRYPTION / DECRYPTION
// RSA-OAEP SECURE KEY SHARING
// ========================================

console.log("🔐 Encryption module loading...");


// ========================================
// INDEXEDDB - OPEN DATABASE
// ========================================

function openEncryptionDB() {

    return new Promise((resolve, reject) => {

        const request = indexedDB.open(
            "SecureFileVaultDB",
            1
        );

        request.onupgradeneeded = function () {

            const db = request.result;

            if (
                !db.objectStoreNames.contains(
                    "encryptionKeys"
                )
            ) {

                db.createObjectStore(
                    "encryptionKeys"
                );
            }
        };

        request.onsuccess = function () {

            resolve(request.result);
        };

        request.onerror = function () {

            reject(request.error);
        };
    });
}


// ========================================
// SAVE ENCRYPTION KEY
// ========================================

async function saveEncryptionKey(
    keyId,
    keyBase64
) {

    if (!keyId || !keyBase64) {

        throw new Error(
            "Invalid encryption key information."
        );
    }

    const db =
        await openEncryptionDB();

    return new Promise((resolve, reject) => {

        const transaction =
            db.transaction(
                "encryptionKeys",
                "readwrite"
            );

        const store =
            transaction.objectStore(
                "encryptionKeys"
            );

        store.put(
            keyBase64,
            "file_key_" + keyId
        );

        transaction.oncomplete =
            function () {

                db.close();

                console.log(
                    "💾 Encryption key permanently saved:",
                    keyId
                );

                resolve();
            };

        transaction.onerror =
            function () {

                db.close();

                reject(
                    transaction.error
                );
            };
    });
}


// ========================================
// GET ENCRYPTION KEY
// ========================================

async function getEncryptionKey(
    keyId
) {

    if (!keyId) {

        return null;
    }

    const db =
        await openEncryptionDB();

    return new Promise((resolve, reject) => {

        const transaction =
            db.transaction(
                "encryptionKeys",
                "readonly"
            );

        const store =
            transaction.objectStore(
                "encryptionKeys"
            );

        const request =
            store.get(
                "file_key_" + keyId
            );

        request.onsuccess =
            function () {

                const key =
                    request.result || null;

                db.close();

                resolve(key);
            };

        request.onerror =
            function () {

                db.close();

                reject(
                    request.error
                );
            };
    });
}


// ========================================
// GET ALL STORED ENCRYPTION KEYS
// Used as fallback for old files
// ========================================

async function getAllEncryptionKeys() {

    const db =
        await openEncryptionDB();

    return new Promise((resolve, reject) => {

        const transaction =
            db.transaction(
                "encryptionKeys",
                "readonly"
            );

        const store =
            transaction.objectStore(
                "encryptionKeys"
            );

        const request =
            store.openCursor();

        const keys = [];

        request.onsuccess =
            function (event) {

                const cursor =
                    event.target.result;

                if (cursor) {

                    const keyName =
                        String(cursor.key);

                    if (
                        keyName.startsWith(
                            "file_key_"
                        )
                    ) {

                        keys.push({

                            keyId:
                                keyName.substring(
                                    "file_key_".length
                                ),

                            keyBase64:
                                cursor.value
                        });
                    }

                    cursor.continue();

                }
                else {

                    db.close();

                    resolve(keys);
                }
            };

        request.onerror =
            function () {

                db.close();

                reject(
                    request.error
                );
            };
    });
}


// ========================================
// IMPORT AES KEY
// ========================================

async function importAESKey(
    keyBase64
) {

    if (!keyBase64) {

        throw new Error(
            "AES key is missing."
        );
    }

    const keyBuffer =
        base64ToArrayBuffer(
            keyBase64,
            "AES encryption key"
        );

    return await crypto.subtle.importKey(
        "raw",
        keyBuffer,
        {
            name: "AES-GCM"
        },
        false,
        [
            "decrypt"
        ]
    );
}


// ========================================
// ENCRYPT FILE
// ========================================

async function encryptFile(file) {

    console.log(
        "🔐 Encrypting:",
        file?.name
    );

    if (!file) {

        throw new Error(
            "No file selected."
        );
    }


    // ====================================
    // READ ORIGINAL FILE
    // ====================================

    const fileData =
        await file.arrayBuffer();


    // ====================================
    // GENERATE AES-256 KEY
    // ====================================

    const key =
        await crypto.subtle.generateKey(
            {
                name: "AES-GCM",
                length: 256
            },
            true,
            [
                "encrypt",
                "decrypt"
            ]
        );


    // ====================================
    // GENERATE RANDOM IV
    // ====================================

    const iv =
        crypto.getRandomValues(
            new Uint8Array(12)
        );


    // ====================================
    // ENCRYPT FILE
    // ====================================

    const encryptedData =
        await crypto.subtle.encrypt(
            {
                name: "AES-GCM",
                iv: iv
            },
            key,
            fileData
        );


    // ====================================
    // EXPORT AES KEY
    // ====================================

    const exportedKey =
        await crypto.subtle.exportKey(
            "raw",
            key
        );

    const keyBase64 =
        arrayBufferToBase64(
            exportedKey
        );


    // ====================================
    // CREATE UNIQUE KEY ID
    // ====================================

    const keyId =
        crypto.randomUUID();


    // ====================================
    // SAVE KEY IN INDEXEDDB
    // ====================================

    await saveEncryptionKey(
        keyId,
        keyBase64
    );


    // ====================================
    // SESSION STORAGE
    // Compatibility fallback
    // ====================================

    try {

        sessionStorage.setItem(
            "file_key_" + keyId,
            keyBase64
        );

    }
    catch (error) {

        console.warn(
            "⚠️ sessionStorage unavailable:",
            error
        );
    }


    // ====================================
    // COMBINE IV + CIPHERTEXT
    // ====================================

    const encryptedArray =
        new Uint8Array(
            encryptedData
        );

    const combined =
        new Uint8Array(
            iv.length +
            encryptedArray.length
        );


    // First 12 bytes = IV

    combined.set(
        iv,
        0
    );


    // Remaining bytes = ciphertext

    combined.set(
        encryptedArray,
        iv.length
    );


    console.log(
        "✅ AES-256-GCM encryption successful"
    );

    console.log(
        "🔑 Key ID:",
        keyId
    );


    return {

        encryptedData:
            combined,

        keyId:
            keyId
    };
}


// ========================================
// DECRYPT WITH SPECIFIC AES KEY
// ========================================

async function decryptWithKey(
    encryptedData,
    keyBase64
) {

    if (!encryptedData) {

        throw new Error(
            "Encrypted file data is missing."
        );
    }

    if (!keyBase64) {

        throw new Error(
            "AES decryption key is missing."
        );
    }


    // ====================================
    // IMPORT AES KEY
    // ====================================

    const key =
        await importAESKey(
            keyBase64
        );


    // ====================================
    // CONVERT DATA TO UINT8ARRAY
    // ====================================

    const data =
        new Uint8Array(
            encryptedData
        );


    if (data.length <= 12) {

        throw new Error(
            "Invalid encrypted file."
        );
    }


    // ====================================
    // EXTRACT IV
    // ====================================

    const iv =
        data.slice(
            0,
            12
        );


    // ====================================
    // EXTRACT CIPHERTEXT
    // ====================================

    const cipherData =
        data.slice(
            12
        );


    // ====================================
    // DECRYPT
    // ====================================

    return await crypto.subtle.decrypt(
        {
            name: "AES-GCM",
            iv: iv
        },
        key,
        cipherData
    );
}


// ========================================
// DECRYPT FILE
// ========================================

async function decryptFile(
    encryptedData,
    keyId
) {

    console.log(
        "🔓 Decrypting file..."
    );

    let keyBase64 = null;


    // ====================================
    // METHOD 1 - INDEXEDDB
    // ====================================

    if (keyId) {

        keyBase64 =
            await getEncryptionKey(
                keyId
            );

        if (keyBase64) {

            console.log(
                "✅ Encryption key found in IndexedDB:",
                keyId
            );

            return await decryptWithKey(
                encryptedData,
                keyBase64
            );
        }
    }


    // ====================================
    // METHOD 2 - SESSION STORAGE
    // ====================================

    if (keyId) {

        console.log(
            "⚠️ Key not found in IndexedDB."
        );

        try {

            keyBase64 =
                sessionStorage.getItem(
                    "file_key_" + keyId
                );

        }
        catch (error) {

            console.warn(
                "⚠️ Could not access sessionStorage."
            );
        }


        if (keyBase64) {

            console.log(
                "✅ Key found in sessionStorage."
            );


            // Migrate old key into IndexedDB

            await saveEncryptionKey(
                keyId,
                keyBase64
            );


            return await decryptWithKey(
                encryptedData,
                keyBase64
            );
        }
    }


    // ====================================
    // METHOD 3 - OLD FILE FALLBACK
    // ====================================

    console.log(
        "🔎 Searching stored encryption keys for old file..."
    );

    const allKeys =
        await getAllEncryptionKeys();


    for (
        const storedKey of allKeys
    ) {

        try {

            const decryptedData =
                await decryptWithKey(
                    encryptedData,
                    storedKey.keyBase64
                );


            console.log(
                "✅ Old file key recovered:",
                storedKey.keyId
            );


            return decryptedData;

        }
        catch (_) {

            // Continue searching
        }
    }


    // ====================================
    // KEY NOT FOUND
    // ====================================

    throw new Error(
        "Encryption key not found. This file was encrypted in a session where its key is no longer available."
    );
}


// ========================================
// GET RAW AES KEY FOR SHARING
// ========================================

async function getEncryptionKeyForSharing(
    keyId
) {

    if (!keyId) {

        throw new Error(
            "Key ID is required."
        );
    }


    // ====================================
    // FIRST TRY INDEXEDDB
    // ====================================

    let keyBase64 =
        await getEncryptionKey(
            keyId
        );


    // ====================================
    // FALLBACK TO SESSION STORAGE
    // ====================================

    if (!keyBase64) {

        try {

            keyBase64 =
                sessionStorage.getItem(
                    "file_key_" + keyId
                );

        }
        catch (error) {

            console.warn(
                "⚠️ sessionStorage unavailable."
            );
        }
    }


    if (!keyBase64) {

        throw new Error(
            "Encryption key not found for sharing."
        );
    }


    console.log(
        "🔑 Encryption key retrieved for secure sharing:",
        keyId
    );


    return keyBase64;
}


// ========================================
// SAVE RECEIVED SHARED AES KEY
// ========================================

async function saveReceivedSharedKey(
    keyId,
    keyBase64
) {

    if (!keyId || !keyBase64) {

        throw new Error(
            "Invalid shared key information."
        );
    }


    await saveEncryptionKey(
        keyId,
        keyBase64
    );


    console.log(
        "🔐 Shared encryption key saved securely:",
        keyId
    );


    return true;
}


// ========================================
// RSA-OAEP GENERATE KEY PAIR
// ========================================

async function generateSharingKeyPair() {

    const keyPair =
        await crypto.subtle.generateKey(
            {
                name: "RSA-OAEP",
                modulusLength: 2048,
                publicExponent:
                    new Uint8Array([
                        1,
                        0,
                        1
                    ]),
                hash: "SHA-256"
            },
            true,
            [
                "encrypt",
                "decrypt"
            ]
        );


    console.log(
        "🔐 RSA-OAEP sharing key pair generated."
    );


    return keyPair;
}


// ========================================
// EXPORT RSA PUBLIC KEY
// ========================================

async function exportPublicSharingKey(
    publicKey
) {

    const exported =
        await crypto.subtle.exportKey(
            "spki",
            publicKey
        );


    return arrayBufferToBase64(
        exported
    );
}


// ========================================
// EXPORT RSA PRIVATE KEY
// ========================================

async function exportPrivateSharingKey(
    privateKey
) {

    const exported =
        await crypto.subtle.exportKey(
            "pkcs8",
            privateKey
        );


    return arrayBufferToBase64(
        exported
    );
}


// ========================================
// NORMALIZE BASE64
// ========================================

function normalizeBase64(
    value,
    label
) {

    if (
        value === null ||
        value === undefined
    ) {

        throw new Error(
            label + " is missing."
        );
    }


    if (
        typeof value !== "string"
    ) {

        throw new Error(
            label + " is not a valid string."
        );
    }


    let clean =
        value.trim();


    // ====================================
    // HANDLE PEM PUBLIC KEY
    // ====================================

    clean =
        clean.replace(
            /-----BEGIN [^-]+-----/g,
            ""
        );

    clean =
        clean.replace(
            /-----END [^-]+-----/g,
            ""
        );


    // ====================================
    // REMOVE WHITESPACE
    // ====================================

    clean =
        clean.replace(
            /\s/g,
            ""
        );


    // ====================================
    // BASE64URL → BASE64
    // ====================================

    clean =
        clean
            .replace(/-/g, "+")
            .replace(/_/g, "/");


    // ====================================
    // REMOVE EXISTING PADDING
    // ====================================

    clean =
        clean.replace(
            /=+$/,
            ""
        );


    // ====================================
    // CHECK CHARACTERS
    // ====================================

    if (
        !/^[A-Za-z0-9+/]*$/.test(
            clean
        )
    ) {

        console.error(
            "❌ Invalid Base64 characters in:",
            label,
            {
                type: typeof value,
                length: value.length,
                prefix:
                    value.substring(
                        0,
                        30
                    )
            }
        );

        throw new Error(
            "Invalid Base64 data for " +
            label +
            "."
        );
    }


    // ====================================
    // CHECK LENGTH
    // ====================================

    if (
        clean.length % 4 === 1
    ) {

        console.error(
            "❌ Invalid Base64 length:",
            label,
            clean.length
        );

        throw new Error(
            "Invalid Base64 data for " +
            label +
            "."
        );
    }


    // ====================================
    // ADD PADDING
    // ====================================

    while (
        clean.length % 4 !== 0
    ) {

        clean += "=";
    }


    return clean;
}


// ========================================
// IMPORT RSA PUBLIC KEY
// ========================================

async function importPublicSharingKey(
    publicKeyBase64
) {

    if (!publicKeyBase64) {

        throw new Error(
            "Public key is missing."
        );
    }


    console.log(
        "🔐 Importing recipient RSA public key..."
    );


    const cleanBase64 =
        normalizeBase64(
            publicKeyBase64,
            "recipient public key"
        );


    console.log(
        "🔐 Recipient public key format validated.",
        {
            length:
                cleanBase64.length
        }
    );


    let keyBuffer;

    try {

        const binary =
            atob(
                cleanBase64
            );

        const bytes =
            new Uint8Array(
                binary.length
            );

        for (
            let i = 0;
            i < binary.length;
            i++
        ) {

            bytes[i] =
                binary.charCodeAt(i);
        }

        keyBuffer =
            bytes.buffer;

    }
    catch (error) {

        console.error(
            "❌ Recipient public key Base64 decoding failed."
        );

        throw new Error(
            "Recipient public key contains invalid Base64 data."
        );
    }


    try {

        return await crypto.subtle.importKey(
            "spki",
            keyBuffer,
            {
                name: "RSA-OAEP",
                hash: "SHA-256"
            },
            true,
            [
                "encrypt"
            ]
        );

    }
    catch (error) {

        console.error(
            "❌ RSA public key import failed:",
            error
        );

        throw new Error(
            "Recipient public key is not a valid RSA-OAEP public key."
        );
    }
}


// ========================================
// IMPORT RSA PRIVATE KEY
// ========================================

async function importPrivateSharingKey(
    privateKeyBase64
) {

    if (!privateKeyBase64) {

        throw new Error(
            "Private key is missing."
        );
    }


    const keyBuffer =
        base64ToArrayBuffer(
            privateKeyBase64,
            "RSA private key"
        );


    return await crypto.subtle.importKey(
        "pkcs8",
        keyBuffer,
        {
            name: "RSA-OAEP",
            hash: "SHA-256"
        },
        true,
        [
            "decrypt"
        ]
    );
}
// ====================================
// IMPORT RECIPIENT PUBLIC SHARING KEY
// Supports:
// 1. SPKI Base64
// 2. JWK JSON
// 3. JWK JSON string
// ====================================

async function importPublicSharingKey(publicKeyData) {

    if (!publicKeyData) {
        throw new Error("Recipient public key is missing.");
    }

    try {

        // --------------------------------
        // Convert value to string
        // --------------------------------

        const keyString = String(publicKeyData).trim();

        console.log(
            "🔐 Importing recipient public key..."
        );

        console.log(
            "📦 Key type:",
            typeof publicKeyData
        );

        console.log(
            "📏 Key length:",
            keyString.length
        );

        console.log(
            "🔎 Key prefix:",
            keyString.substring(0, 50)
        );


        // ====================================
        // CASE 1: JWK JSON
        // ====================================

        if (
            keyString.startsWith("{") &&
            keyString.endsWith("}")
        ) {

            let jwk;

            try {

                jwk = JSON.parse(keyString);

            } catch (jsonError) {

                console.error(
                    "❌ Recipient public key contains invalid JSON:",
                    jsonError
                );

                throw new Error(
                    "Recipient public key contains invalid JWK JSON."
                );
            }


            console.log(
                "✅ Recipient key detected as JWK."
            );


            // Validate JWK fields

            if (!jwk.kty) {
                throw new Error(
                    "Recipient JWK is missing kty."
                );
            }

            if (jwk.kty !== "RSA") {
                throw new Error(
                    "Recipient public key is not an RSA key."
                );
            }

            if (!jwk.n || !jwk.e) {
                throw new Error(
                    "Recipient RSA JWK is missing n or e."
                );
            }


            // Import JWK directly

            const cryptoKey =
                await crypto.subtle.importKey(
                    "jwk",
                    jwk,
                    {
                        name: "RSA-OAEP",
                        hash: "SHA-256"
                    },
                    false,
                    ["encrypt"]
                );


            console.log(
                "✅ Recipient JWK imported successfully."
            );

            return cryptoKey;
        }


        // ====================================
        // CASE 2: SPKI BASE64
        // ====================================

        console.log(
            "🔐 Recipient key detected as SPKI Base64."
        );


        const normalizedKey =
            normalizeBase64(
                keyString,
                "recipient public key"
            );


        const binary =
            atob(normalizedKey);


        const bytes =
            new Uint8Array(binary.length);


        for (
            let i = 0;
            i < binary.length;
            i++
        ) {
            bytes[i] =
                binary.charCodeAt(i);
        }


        const cryptoKey =
            await crypto.subtle.importKey(
                "spki",
                bytes.buffer,
                {
                    name: "RSA-OAEP",
                    hash: "SHA-256"
                },
                false,
                ["encrypt"]
            );


        console.log(
            "✅ Recipient SPKI public key imported successfully."
        );


        return cryptoKey;

    } catch (error) {

        console.error(
            "❌ Failed to import recipient public key:",
            error
        );

        throw new Error(
            "Recipient public key could not be imported."
        );
    }
}

// ========================================
// SAVE RSA SHARING KEY PAIR
// ========================================

async function saveSharingKeyPair(
    publicKeyBase64,
    privateKeyBase64
) {

    if (
        !publicKeyBase64 ||
        !privateKeyBase64
    ) {

        throw new Error(
            "Invalid RSA key pair."
        );
    }


    const db =
        await openEncryptionDB();


    return new Promise((resolve, reject) => {

        const transaction =
            db.transaction(
                "encryptionKeys",
                "readwrite"
            );


        const store =
            transaction.objectStore(
                "encryptionKeys"
            );


        // Save public key

        store.put(
            publicKeyBase64,
            "sharing_public_key"
        );


        // Save private key

        store.put(
            privateKeyBase64,
            "sharing_private_key"
        );


        transaction.oncomplete =
            function () {

                db.close();


                console.log(
                    "💾 RSA sharing key pair saved in IndexedDB."
                );


                resolve();
            };


        transaction.onerror =
            function () {

                db.close();


                reject(
                    transaction.error
                );
            };
    });
}


// ========================================
// GET SAVED RSA PUBLIC KEY
// ========================================

async function getSharingPublicKey() {

    const db =
        await openEncryptionDB();


    return new Promise((resolve, reject) => {

        const transaction =
            db.transaction(
                "encryptionKeys",
                "readonly"
            );


        const store =
            transaction.objectStore(
                "encryptionKeys"
            );


        const request =
            store.get(
                "sharing_public_key"
            );


        request.onsuccess =
            function () {

                const key =
                    request.result || null;


                db.close();


                resolve(key);
            };


        request.onerror =
            function () {

                db.close();


                reject(
                    request.error
                );
            };
    });
}


// ========================================
// GET SAVED RSA PRIVATE KEY
// ========================================

async function getSharingPrivateKey() {

    const db =
        await openEncryptionDB();


    return new Promise((resolve, reject) => {

        const transaction =
            db.transaction(
                "encryptionKeys",
                "readonly"
            );


        const store =
            transaction.objectStore(
                "encryptionKeys"
            );


        const request =
            store.get(
                "sharing_private_key"
            );


        request.onsuccess =
            function () {

                const key =
                    request.result || null;


                db.close();


                resolve(key);
            };


        request.onerror =
            function () {

                db.close();


                reject(
                    request.error
                );
            };
    });
}


// ========================================
// ENSURE LOCAL RSA SHARING KEY PAIR
// ========================================

async function ensureLocalSharingKeyPair() {

    console.log(
        "🔐 Checking RSA sharing key pair..."
    );


    // ====================================
    // CHECK EXISTING KEYS
    // ====================================

    let publicKeyBase64 =
        await getSharingPublicKey();

    let privateKeyBase64 =
        await getSharingPrivateKey();


    if (
        publicKeyBase64 &&
        privateKeyBase64
    ) {

        console.log(
            "✅ Existing RSA sharing key pair found."
        );


        return {

            publicKey:
                publicKeyBase64,

            privateKey:
                privateKeyBase64
        };
    }


    // ====================================
    // GENERATE NEW KEY PAIR
    // ====================================

    console.log(
        "🆕 Generating new RSA sharing key pair..."
    );


    const keyPair =
        await generateSharingKeyPair();


    // ====================================
    // EXPORT KEYS
    // ====================================

    publicKeyBase64 =
        await exportPublicSharingKey(
            keyPair.publicKey
        );


    privateKeyBase64 =
        await exportPrivateSharingKey(
            keyPair.privateKey
        );


    // ====================================
    // SAVE KEYS
    // ====================================

    await saveSharingKeyPair(
        publicKeyBase64,
        privateKeyBase64
    );


    console.log(
        "✅ New RSA sharing key pair created and saved."
    );


    return {

        publicKey:
            publicKeyBase64,

        privateKey:
            privateKeyBase64
    };
}


// ========================================
// RSA-OAEP WRAP AES KEY FOR SHARING
// ========================================

async function wrapAESKeyForSharing(
    keyId,
    recipientPublicKeyBase64
) {

    if (
        !keyId ||
        !recipientPublicKeyBase64
    ) {

        throw new Error(
            "Key ID and recipient public key are required."
        );
    }


    // ====================================
    // GET OWNER AES KEY
    // ====================================

    const aesKeyBase64 =
        await getEncryptionKeyForSharing(
            keyId
        );


    if (!aesKeyBase64) {

        throw new Error(
            "AES encryption key not found."
        );
    }


    // ====================================
    // IMPORT RECIPIENT RSA PUBLIC KEY
    // ====================================

    console.log(
        "🔐 Validating recipient public key..."
    );


    const publicKey =
        await importPublicSharingKey(
            recipientPublicKeyBase64
        );


    // ====================================
    // CONVERT AES KEY TO BYTES
    // ====================================

    console.log(
        "🔑 Converting AES key to bytes..."
    );


    const aesKeyBuffer =
        base64ToArrayBuffer(
            aesKeyBase64,
            "AES encryption key"
        );


    // ====================================
    // RSA-OAEP ENCRYPT AES KEY
    // ====================================

    const wrappedKey =
        await crypto.subtle.encrypt(
            {
                name: "RSA-OAEP"
            },
            publicKey,
            aesKeyBuffer
        );


    // ====================================
    // CONVERT TO BASE64
    // ====================================

    const wrappedKeyBase64 =
        arrayBufferToBase64(
            wrappedKey
        );


    console.log(
        "🔐 AES key successfully wrapped with recipient RSA public key."
    );


    return wrappedKeyBase64;
}


// ========================================
// RSA-OAEP UNWRAP AES KEY
// ========================================

async function unwrapAESKeyFromSharing(
    wrappedKeyBase64,
    privateKeyBase64
) {

    if (
        !wrappedKeyBase64 ||
        !privateKeyBase64
    ) {

        throw new Error(
            "Wrapped key and private key are required."
        );
    }


    // ====================================
    // IMPORT RECIPIENT PRIVATE KEY
    // ====================================

    const privateKey =
        await importPrivateSharingKey(
            privateKeyBase64
        );


    // ====================================
    // CONVERT WRAPPED KEY
    // ====================================

    const wrappedKeyBuffer =
        base64ToArrayBuffer(
            wrappedKeyBase64,
            "wrapped RSA key"
        );


    // ====================================
    // RSA-OAEP DECRYPT
    // ====================================

    const aesKeyBuffer =
        await crypto.subtle.decrypt(
            {
                name: "RSA-OAEP"
            },
            privateKey,
            wrappedKeyBuffer
        );


    // ====================================
    // CONVERT AES KEY TO BASE64
    // ====================================

    const aesKeyBase64 =
        arrayBufferToBase64(
            aesKeyBuffer
        );


    console.log(
        "🔓 AES key successfully unwrapped using RSA private key."
    );


    return aesKeyBase64;
}


// ========================================
// ARRAY BUFFER → BASE64
// ========================================

function arrayBufferToBase64(
    buffer
) {

    const bytes =
        new Uint8Array(
            buffer
        );


    let binary = "";


    for (
        let i = 0;
        i < bytes.length;
        i++
    ) {

        binary +=
            String.fromCharCode(
                bytes[i]
            );
    }


    return btoa(
        binary
    );
}


// ========================================
// BASE64 → ARRAY BUFFER
// ========================================

function base64ToArrayBuffer(
    base64,
    label = "data"
) {

    const cleanBase64 =
        normalizeBase64(
            base64,
            label
        );


    let binary;

    try {

        binary =
            atob(
                cleanBase64
            );

    }
    catch (error) {

        console.error(
            "❌ Base64 decoding failed:",
            {
                label:
                    label,

                type:
                    typeof base64,

                length:
                    typeof base64 === "string"
                        ? base64.length
                        : 0,

                prefix:
                    typeof base64 === "string"
                        ? base64.substring(
                            0,
                            30
                        )
                        : ""
            }
        );


        throw new Error(
            "Invalid Base64 data for " +
            label +
            "."
        );
    }


    const bytes =
        new Uint8Array(
            binary.length
        );


    for (
        let i = 0;
        i < binary.length;
        i++
    ) {

        bytes[i] =
            binary.charCodeAt(i);
    }


    return bytes.buffer;
}


// ========================================
// GLOBAL AES FUNCTIONS
// ========================================

window.encryptFile =
    encryptFile;

window.decryptFile =
    decryptFile;

window.decryptWithKey =
    decryptWithKey;

window.saveEncryptionKey =
    saveEncryptionKey;

window.getEncryptionKey =
    getEncryptionKey;

window.getAllEncryptionKeys =
    getAllEncryptionKeys;

window.getEncryptionKeyForSharing =
    getEncryptionKeyForSharing;

window.saveReceivedSharedKey =
    saveReceivedSharedKey;


// ========================================
// GLOBAL RSA FUNCTIONS
// ========================================

window.generateSharingKeyPair =
    generateSharingKeyPair;

window.exportPublicSharingKey =
    exportPublicSharingKey;

window.exportPrivateSharingKey =
    exportPrivateSharingKey;

window.importPublicSharingKey =
    importPublicSharingKey;

window.importPrivateSharingKey =
    importPrivateSharingKey;

window.saveSharingKeyPair =
    saveSharingKeyPair;

window.getSharingPublicKey =
    getSharingPublicKey;

window.getSharingPrivateKey =
    getSharingPrivateKey;

window.ensureLocalSharingKeyPair =
    ensureLocalSharingKeyPair;

window.wrapAESKeyForSharing =
    wrapAESKeyForSharing;

window.unwrapAESKeyFromSharing =
    unwrapAESKeyFromSharing;


// ========================================
// MODULE LOADED
// ========================================

console.log(
    "✅ AES-256-GCM Encryption Loaded"
);

console.log(
    "✅ RSA-OAEP Secure Sharing Loaded"
);

console.log(
    "✅ RSA Key Storage Loaded"
);

console.log(
    "✅ RSA AES-Key Wrapping Loaded"
);
// ====================================
// REGENERATE LOCAL RSA SHARING KEYS
// ====================================

async function regenerateSharingKeys() {
    try {
        console.log("🔄 Regenerating RSA sharing keys...");

        // Generate a completely new RSA key pair
        const keyPair = await generateSharingKeyPair();

        // Export keys as Base64
        const publicKeyBase64 =
            await exportPublicSharingKey(keyPair.publicKey);

        const privateKeyBase64 =
            await exportPrivateSharingKey(keyPair.privateKey);

        // Save new keys in IndexedDB
        await saveSharingKeyPair(
            publicKeyBase64,
            privateKeyBase64
        );

        console.log("✅ New RSA key pair generated.");
        console.log(
            "🔑 New public key length:",
            publicKeyBase64.length
        );

        // Get logged-in user
        const {
            data: { user },
            error: userError
        } = await supabaseClient.auth.getUser();

        if (userError || !user) {
            throw new Error("User is not logged in.");
        }

        // Replace public key in Supabase
        const { error: dbError } =
            await supabaseClient
                .from("user_keys")
                .upsert(
                    {
                        user_id: user.id,
                        email: user.email,
                        public_key: publicKeyBase64
                    },
                    {
                        onConflict: "user_id"
                    }
                );

        if (dbError) {
            console.error(
                "❌ Failed to update user_keys:",
                dbError
            );
            throw dbError;
        }

        console.log("✅ Public key updated in user_keys.");
        console.log("📧 User:", user.email);

        return true;

    } catch (error) {

        console.error(
            "❌ Key regeneration failed:",
            error
        );

        throw error;
    }
}